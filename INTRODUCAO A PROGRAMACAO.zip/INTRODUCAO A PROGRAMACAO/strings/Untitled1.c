#include<stdio.h>
#include<string.h>

int main ()
{
    char a[50];
    char b[50];
    char c[50];
    int i,n;
       printf ("digite a quantidade de alteracaoes que deseja fazer :  ");
       scanf("%d",&n);

          printf("digite  duas  palavras : ");
          scanf("%s%s",&a[50],&b[50]);




          for (i=0;i<=n;i++){
               c[0]=a[0];
               c[i]=b[i];}
         printf("a  nova palavra e : %c \n",c[i]);








          }

