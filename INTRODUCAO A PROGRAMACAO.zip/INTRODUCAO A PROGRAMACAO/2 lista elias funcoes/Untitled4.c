#include <stdio.h>

double raiz(double n, double e);

double absoluto( double n );

int main(){
double n;
double e;

scanf("%lf", &n);
scanf("%lf", &e);


raiz(n, e);

return 0;
}

double raiz(double n, double e){
double err;
double rk;
double r_anterior = 1;

rk = (r_anterior + (n/r_anterior))/2.0;

while((absoluto(n - (rk*rk))) > e){
err = (absoluto(n - (rk*rk)));
printf("r: %.9lf, err: %.9lf\n", rk, err);
r_anterior = rk;
rk = (r_anterior + (n/r_anterior))/2.0;
}
err = (absoluto(n - (rk*rk)));
printf("r: %.9lf, err: %.9lf\n", rk, err);

return 0;
}

double absoluto( double n ){
if(n >= 0) return n;
else return -n;
}
