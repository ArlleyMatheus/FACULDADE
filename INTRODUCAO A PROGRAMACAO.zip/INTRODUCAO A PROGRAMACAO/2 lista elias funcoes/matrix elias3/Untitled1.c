#include<stdio.h>
int main (){
    float m[2][2];
    int i,j;
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
         //   printf("digite o %d elemento da linha e %d coluna",i+1,j+1);
            scanf("%f",&m[i][j]);

        }
    }
    float soma =0;
      for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            soma=(m[0][0]*m[1][1])-(m[0][1]*m[1][0]);
        }
      }
       printf("%.2f\n",soma);

}
