#include<stdio.h>
#include<math.h>
int main (){
    int n=2,i,j;
    float  m[2][2],mul=0;
    //scanf("%d",&n);
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            scanf("%d",&m[i][j]);
        }
    }
     for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            mul=m[0][0]*m[0][0];
            //printf("%.2f",mul);
            mul=mul+(m[0][1]*m[1][0]);
            printf("%.2f",mul);
        }
            printf("\n");
        }
           for(i=0;i<n;i++){
            for(j=0;j<n;j++){
                mul=m[1][0]*m[0][0];
                printf("%.2f",mul);
                mul=mul+(m[1][1]*m[1][0]);
                printf("%.2f",mul);
        }
            printf("\n");
        }
     }


