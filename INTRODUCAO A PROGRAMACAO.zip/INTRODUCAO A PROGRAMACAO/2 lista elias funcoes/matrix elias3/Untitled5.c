#include<stdio.h>
int main (){
    int n,n1,i,j;
    int m[100][100];
    scanf("%d",&n);
    scanf("%d",&n1);


     for(i=0;i<n;i++){
        for(j=0;j<n1;j++){
            if(((i+j)%2)==0){
                    m[i][j]=1;
            }
            else{
                m[i][j]=0;
            }
        }
    }
        //printf("passou");
     for(i=0;i<n;i++){
        for(j=0;j<n1;j++){
            printf("%d",m[i][j]);
            }
        printf("\n");
     }
}

