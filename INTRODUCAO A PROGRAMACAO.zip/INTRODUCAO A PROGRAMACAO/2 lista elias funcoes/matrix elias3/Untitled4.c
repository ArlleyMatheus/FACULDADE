#include<stdio.h>
int main (){
    int n,n1,i,j;
    int m[100][100];
    scanf("%d",&n);
    while(n>10||n<=0){
        scanf("%d",&n);
    }
    scanf("%d",&n1);
    while(n1>10||n1<=0){
        scanf("%d",&n1);
    }
    for(i=0;i<n;i++){
        for(j=0;j<n1;j++){
            scanf("%d",&m[i][j]);
        }
    }
    int k=0;
     for(i=0;i<n;i++){
        printf("linha %d: ",i+1);
        for(j=0;j<n1;j++){
            if(j>0 && j<n1 ){
                printf(",");
                }
            printf("%d",m[i][j]);
        }
        printf("\n");
     }

}
