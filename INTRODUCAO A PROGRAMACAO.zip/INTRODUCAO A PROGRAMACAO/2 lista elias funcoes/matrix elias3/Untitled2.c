#include<stdio.h>
int main (){
    int n,i,j;
    int m[100][100];
    scanf("%d",&n);
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            scanf("%d",&m[i][j]);
        }
    }
     for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if(i==j){
                printf("%d\n",m[i][j]);
            }
        }
     }

}
