#include<stdio.h>
int calcular_digitos_cpf(int n){
        int resto1=0,mul=0,resto2=0,mul1=0,v1=0,v2=0,v=0,a,b,c,d,e,f,g,h,i;
         a=n/100000000;
         b=(n%100000000)/10000000;
         c=((n%100000000)%10000000)/1000000;
         d=(n%1000000000)%10000000 %1000000/100000;
         e=(n%1000000000)%10000000 %1000000%100000/10000;
         f=(n%1000000000)%10000000 %1000000%100000%10000/1000;
         g=(n%1000000000)%10000000 %1000000%100000%10000%1000/100;
         h=(n%1000000000)%10000000 %1000000%100000%10000%1000%100/10;
         i=(n%1000000000)%10000000 %1000000%100000%10000%1000%100%10/1;
        mul=(a*10)+(b*9)+(c*8)+(d*7)+(e*6)+(f*5)+(g*4)+(h*3)+(i*2);
        v1=(11-(mul%11));
        if(v1 > 9){
        resto1=0;
        }
        else {
            resto1=v1;
        }
        mul1=(a*11)+(b*10)+(c*9)+(d*8)+(e*7)+(f*6)+(g*5)+(h*4)+(i*3)+(resto1*2);
         v2=(11-(mul1%11));

        if ( v2 > 9){
            resto2=0;
        }
        else{
            resto2=v2;
            }
            v = (resto1*10)+resto2;
         return v;




            }
int main (){
     int n,res;

   //  printf("digite um numro de 9 digitos ");
     scanf("%d",&n);
     if(n<11){
        printf("digito invalido\n");
     }
     else{
   // printf("%d\n",a);
    //printf("%d\n",b);
    //printf("%d\n",c);
    //printf("%d\n",d);
    //printf("%d\n",e);
    //printf("%d\n",f);
    //printf("%d\n",g);
    //printf("%d\n",h);
    //printf("%d\n",i);

        res= calcular_digitos_cpf(n);
        if (res<10){
            printf("0%d\n",res);
        }
        else{
            printf("%d\n",res);
        }
    }
}







