#include<stdio.h>
int main (){
    int n;
    int v[1000];
    int  i,j, quant,k,tam,aux,maior=0,menor,cont=0;
   // printf("digite a quantidade de testes: ");
    scanf("%d",&n);
   while(n<1 || n>10){
        if(n<1 || n>10){
           // printf("invalido");
             scanf("%d",&n);
        }
   }
        for(k=0;k<n;k++){
           // printf("digite o tamanho do %d vetor ",k+1);
            scanf("%d",&tam);
            while(tam<2|| tam>1000){
                if(tam<2 || tam>1000){
             //       printf("invalido");
                    scanf("%d",&tam);
                }
            }
            for(i=0;i<tam;i++){
               // printf("digite o %d elemento do vetor : ",i+1);
                scanf("%d",&v[i]);
                while(v[i]<-1000 || v[i]>1000){
                    if(v[i]< -1000 || v[i]>1000){
               //         printf("invalido");
                        scanf("%d",&v[i]);
                    }
                }
                if(v[i]>maior)
                    maior=v[i];

            }
            menor=maior;
          //  printf("%d\n",menor);
            for(i=0;i<tam-1;i++){
                for(j=i+1;j<tam;j++){
                    if(v[i]>v[j]){
                        aux=v[i];
                        v[i]=v[j];
                        v[j]=aux;


                    }
                }
            }
          //  printf("%d",cont);
            for(i=0;i<tam-1;i++){
                    for(j=i+1;j<tam;j++){
                        if(v[j]-v[i]<menor){
                            menor=v[j]-v[i];
                        }
                        if(v[j]-v[i]>maior && tam==2){
                                menor=v[j]-v[i];

                        }
                    }
            }

            printf("%d %d\n",menor,tam*tam);
        }
}




