#include <stdio.h>
#include <string.h>
#include <math.h>
int main (){
    int frase[100];
    int oracao[100];
    int i;
    printf("digiet uma frase: ");
    i=0;
    while(frase[i] != ';'){
           // printf("entrou aki\n");
        scanf("%s",&frase);
        gechar()=frase;
        if(getchar== ';'){
            return 1;
        }
        printf("%s",frase);
    }
      printf("%s",frase);

}


