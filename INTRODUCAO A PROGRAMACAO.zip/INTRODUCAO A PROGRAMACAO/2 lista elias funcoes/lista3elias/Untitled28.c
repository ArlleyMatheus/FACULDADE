#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main (){
    int q1,q2,i,j,cont=1,aux=0,k,num=0;
    float *pv,*sv;
     float *vf;
    scanf("%d",&q1);
    scanf("%d",&q2);

    while(q1>q2){
        scanf("%d",&q2);
    }
    int mul=q1+q2;
    while(q1<0 ||q1>500000 || q2 < 0 || q2> 500000){
        scanf("%d %d",&q1,&q2);
    }
    pv  =(int*)malloc(q1*sizeof(int));
    sv =(int*)malloc(q2*sizeof(int));
    vf =(int*)malloc(mul*sizeof(int));
    num=0;
    for(i=2;i<q1+2;i++){
        scanf("%f",&pv[i]);
        while(pv[i]< num || pv[i]<0 || pv[i]>999999){
             //   printf("invalido");

                scanf("%f",&pv[i]);


        }

        num=pv[i];
    }
    num=0;

    for(j=2;j<q2+2;j++){
        scanf("%f",&sv[j]);
            while( sv[j]< num || sv[j]<0|| sv[j]>999999){
           //     printf("invalido");
                scanf("%f",&sv[j]);
            }
        num=sv[j];
    }

     cont=1;
    aux=0;
    j=2;
    k=2;
    aux=q1+q2+1;
   // printf("%d",aux);
    for(i=2;i<q1+q2+2;i++){
            if( i%2 == 0){
                vf[i]=sv[j];
                j++;

            }
            else{
                if(q1!=q2){
                    if(i == aux){
                        vf[i]=sv[j];
                      //  printf("aki esta o %d\n",sv[j]);
                    }
                    else{
                        vf[i] =pv[k];
                        k=k+1;
                    }
                }
                    else{
                       if(i == aux){
                        vf[i]=pv[k];
                       // printf("aki esta o %d\n",pv[k]);
                    }
                    else{
                        vf[i] =pv[k];
                        k=k+1;
                    }
                }
                }
    }


  while(cont!=0){
        cont=0;
        for(i=2;i<q1+q2+1;i++){
            for(j=i+1;j<q1+q2+2;j++){
                if(vf[i]>vf[j]){
                    aux=vf[i];
                    vf[i]=vf[j];
                    vf[j]=aux;
                    cont=1;
                }
            }
        }
    }
    for(i=2;i<q1+q2+2;i++){
       printf("%.0f\n",vf[i]);
    }

//    free(*pv);
//  free(*sv);
  //free(*vf);
    return 0;

}


