#include<stdio.h>
int main(){
    int n,v[1000],i,maior=0,menor=maior,j;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d",&v[i]);
        if(maior<v[i]){
            maior=v[i];
        }
    }
    menor=maior;
     for(i=1;i<=n;i++){
            if(v[i]<menor){
                menor=v[i];
            }
     }
    for(i=1;i<=n;i++){
        printf("%d ",v[i]);
    }
    printf("\n");
     for(j=n;j>0;j--){
        printf("%d ",v[j]);
     }
     printf("\n");
    printf("%d\n",maior);
    printf("%d\n",menor);

    }

