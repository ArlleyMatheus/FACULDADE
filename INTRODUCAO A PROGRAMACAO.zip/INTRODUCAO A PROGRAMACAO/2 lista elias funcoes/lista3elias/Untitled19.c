#include<stdio.h>
int main(){
    int j,n,i,v[1000],num=0,aux=0;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
    }
    for(i=0;i<n-1;i++){
        for(j=i+1;j<n;j++){
            if(v[i]>v[j]){
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
        }
    }
    for(i=0;i<n;i++){
        if(v[i]==v[i+1]){
               // printf("%d == %d\n",v[i],v[i+1]);

        }
        else{
            printf("%d\n",v[i]);
        }


    }
}
