#include<stdio.h>
int main(){
    int n,v[100000],cont=1,valor=0;
    int i,j,aux=0;
    float media=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d",&v[i]);
    }
    while(cont!=0){
            cont=0;
        for(i=1;i<=n-1;i++){
            for(j=i+1;j<=n;j++){
                    if(v[i]>v[j]){
                            aux=v[i];
                            v[i]=v[j];
                            v[j]=aux;
                            cont=1;
                    }
            }
        }
    }
    if(n%2==0){
            valor=n/2;
            media=v[valor]+v[valor+1];
            media=media/2;

        printf("%.2f\n",media);
    }
    else{
        valor=n/2;
        valor=valor+1;
        printf("%.2f\n",(float)v[valor]);
    }

}
