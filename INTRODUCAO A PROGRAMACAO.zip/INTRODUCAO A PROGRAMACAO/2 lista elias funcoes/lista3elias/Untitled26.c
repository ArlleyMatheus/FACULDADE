#include<stdio.h>
int main(){
    int n,i,j;
    int v[9];
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        for(int j=0;j<9;j++){
            scanf("%d",&v[i]);
        }

        for(i=0;i<n;i++){
            for(j=i;j<n;j++){
                if(v[i]+[j])
            }
        }




    }




}
