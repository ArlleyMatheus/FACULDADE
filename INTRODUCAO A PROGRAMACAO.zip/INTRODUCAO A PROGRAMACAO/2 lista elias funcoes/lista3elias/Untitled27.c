#include<stdio.h>
int main(){
    int x,y,i,cont=0,aux=0;

    //printf("digite o 1 tamanho");
    scanf("%d",&x);

    while(x<=0||x>100){
        //printf("invalido");
        scanf("%d",&x);
    }
        //printf("digite o 2 tamanho ");
       scanf("%d",&y);
     while(y<=0|| y>100){
        //printf("invalido");
        scanf("%d",&y);
    }


    int u[x],v[y],tam=x+y,pot=(x*y);
    int soma=x+y;
    int num=-88;

    for(i=0;i<x;i++){
       // printf("digite o %d valor",i+1);
        scanf("%d",&u[i]);
        while(num == u[i]){
        //    printf("invalido");
            scanf("%d",&u[i]);
        }
        num = u[i];
    }
    num=-88;

    for(i=0;i<y;i++){
      //  printf("digite o %d valor para o segundo vetor: ",i+1);
       scanf("%d",&v[i]);
            while(num==v[i]){
              //  printf("invalido");
                scanf("%d",&v[i]);
            }
        num = v[i];
    }
    int j;
    for(i=0;i<x;i++){
            for(j=0;j<y;j++){
                    if(u[i]==v[j]){
                        cont+=1;
                    }
        }
    }
    soma=soma-cont;
    int vf[soma];
    int k=0;
    j=0;
    for(i=0;i<soma;i++){
            if(u[j]==v[k] && j<x && k<y){
                vf[i]=u[j];
                j++;
                k++;
            }
            else{
                if(k<y){
                    vf[i]=v[k];
                }
                    else{
                        vf[i]=u[j];
                    }
                }
        }



   // for(i=0;i<soma;i++){
       // printf("%d ",vf[i]);
    //}      j=0;
        printf("(");
        j=0;

        for(i=0;i<soma;i++){
            printf("%d",vf[i]);
            if(i<soma-1){
                printf(",");
            }
        }

            cont=0;
            printf(")");
            printf("\n");

            printf("(");
              for(i=0;i<x;i++){
                for(j=0;j<y;j++){
                        if(u[i]==v[j]){
                            printf("%d",v[j]);
                            cont+=1;
                            if(i<x-cont)
                                printf(",");
                    }

              }

        }
        printf(")\n");
        }







