#include<stdio.h>
int main(){
    int n,v[5000],i,j,cont=0,c[5000],cont2=0;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
    }
    for(i=0;i<n;i++){
            cont=0;
             for(j=0;j<n;j++){
                if(v[i] == v[j]){
                    cont+=1;
                }
             }
        if(cont==1){
            //printf(" %d e unico\n",v[i]);
            cont2+=1;
        }

    }
        printf("%d\n",cont2);
}

