#include<stdio.h>
int main(){
    int soma=0,n,v[5000],i;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
        soma+=v[i];
    }
    printf("%d\n",soma);



}
