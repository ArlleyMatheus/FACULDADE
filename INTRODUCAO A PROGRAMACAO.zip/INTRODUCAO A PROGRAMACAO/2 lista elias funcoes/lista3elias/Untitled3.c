#include<stdio.h>
int main (){
    int n,i,v[5000];
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d",&v[i]);
    }
    for(i=n;i>0;i--){

          //  printf("passou aki ");
        printf("%d ",v[i]);
    }


}
