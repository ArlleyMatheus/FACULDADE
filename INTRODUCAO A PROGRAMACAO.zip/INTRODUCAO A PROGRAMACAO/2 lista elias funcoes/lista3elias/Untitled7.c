#include<stdio.h>
int main (){
    int n,v[10000],i=0,j=0,maior=0,ind=0,cont=0;
    scanf("%d",&n);
    while(n != 0){
            for(i=0;i<n;i++){
                scanf("%d",&v[i]);
                if(maior<v[i]){
                    maior=v[i];
                    ind=i;
                }
            }
                for(j=0;j<=maior;j++){
                    for(i=0;i<n;i++){
                        if(v[i] <= j){
                            cont=cont+1;
                            printf("(%d) = %d\n",j,cont);
                        }
                    }
                }

            scanf("%d",&n);

            }

    }





