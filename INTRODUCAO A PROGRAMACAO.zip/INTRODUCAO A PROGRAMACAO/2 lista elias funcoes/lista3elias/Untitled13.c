#include<stdio.h>
int main(){
    int i,n,j,cont=0,num,novo=0,aux=0;
    int v[100000];
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
    }
    for(i=0;i<n;i++){
    cont=0;
        for(j=0;j<n;j++){
            if(v[i] == v[j]){
                cont+=1;

            }
            if(cont>1 && novo<cont){
                novo=cont;
                num=v[i];
            }
            if(cont==novo && num>v[i]){
                aux=v[i];
                v[i]=num;
                num=aux;
            }
        }
    }
      printf("%d\n%d\n",num,novo);


}
