#include<stdio.h>
int main(){
    int n,i,v[5000];
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
    }
    for(i=0;i<n;i++){
        printf("%d ",v[i]);
    }


}
