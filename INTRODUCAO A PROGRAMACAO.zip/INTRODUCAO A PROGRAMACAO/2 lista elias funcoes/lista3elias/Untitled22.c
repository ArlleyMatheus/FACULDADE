#include<stdio.h>
#include<math.h>

int main(){
    int i=10,n,sub ,tam,res=0,pot=0,dividendo=0,div=0,div1=0,j=1,mult=0,k,maior=0,regular;
    scanf("%d",&tam);
    scanf("%d",&sub);




    while(tam && sub !=0){
            j=1;
        scanf("%d",&n);
        res=n;
         int v[100000]={0};
         v[tam];

        for(pot=tam-1;pot>0;pot--){
            dividendo= pow(i,pot);
            if(pot==1){
                div=res/dividendo;
                div1=res%dividendo;

            }
            else{
                if(dividendo==99)
                    dividendo=100;

               // printf("%d e %d\n",res,dividendo);
                  div=res/dividendo;
                  res=res%dividendo;
            }
        v[j]=div;
        j++;
        //printf("j esta aki = %d\n",j);
        if(j==tam){
                v[j]=div1;
            }
        }for(j=1;j<=tam;j++){
          //  printf("vetor %d ",v[j]);
        }

        if(sub == 1 || 0){
            sub =1;
        }
        else{
            sub=sub-1;
        }if(sub)

        for(j=1;j<=tam;j++){
            for(k=j+1;k<=tam;k++){
                mult = v[j] * (pow(i,sub));
                mult=mult+v[k];
                if(mult>maior){
                    maior=mult;//printf("la dentro = %d\n",maior);
                }
            }
        }

        printf("%d\n",maior);

        scanf("%d %d",&tam,&sub);
    }
}

