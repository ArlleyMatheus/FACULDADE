#include<stdio.h>
int main(){
    int n,i,cont=0;
    int v[1000];
    int k;
  //  printf("digite um numero para o tamanho do vetor ");
    scanf("%d",&n);
    while(n<1 || n>1000){
        if(n<1|| n>1000){
           // printf("digite novamente : ");
            scanf("%d",&n);
        }
    }
    for(i=0;i<n;i++){
       // printf("digite os numeros: ");
        scanf("%d",&v[i]);
    }
  //  printf("digite o valor do numero para contagem : ");
    scanf("%d",&k);
    for(i=0;i<n;i++){
        if(v[i]>=k){
            cont+=1;
        }
    }
    printf("%d\n",cont);



}
