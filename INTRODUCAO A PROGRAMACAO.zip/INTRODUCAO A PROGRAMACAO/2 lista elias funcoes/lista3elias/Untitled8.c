#include<stdio.h>
int main(){
    int n1,j;
    int v[5000],n[11],i,k=0,soma=0,soma1=0;
    scanf("%d",&n1);
    i=n1;
    while(i!=0 ){
        for(j=1;j<=11;j++){
            scanf("%d",&n[j]);
        }




        k=0;
        for(j=1;j<=9;j++){
            k+=1;
            soma=(n[j]*k)+soma;
          //  printf(" 1 %d soma %d\n",soma,k);
        }
        k=10;
        for(j=1;j<=9;j++){
            k-=1;
            soma1 =(n[j]*k) + soma1;
            //printf("2 %d soma %d\n",soma1,k);
        }
        soma=soma%11;
        //printf("3 %d\n",soma);
        soma1=soma1%11;
         //printf("4 %d\n",soma1);
        if(soma>9){
            soma=0;
        }
        else{
            soma=soma;
        }
        if(soma1>9){
            soma1=0;
        }
        else{
            soma1=soma1;
        }
       // printf("%d e %d",soma,soma1);
        if((n[10] == soma && n[11] == soma1)){
            printf("CPF valido\n");
        }
        else{
            printf("CPF invalido\n");
        }
        soma=0;soma1=0;

    i--;
}
}

