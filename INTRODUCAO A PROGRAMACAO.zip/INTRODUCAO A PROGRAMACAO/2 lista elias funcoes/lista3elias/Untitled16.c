#include<stdio.h>
int main(){
    int n,i,j;
    int k,cont=0;
    int v[1000];
    scanf("%d %d",&n,&k);
    for(i=0;i<n;i++){
        scanf("%d",&v[i]);
    }
      for(i=0;i<n;i++){
            if(v[i]<=0){
                cont++;
            }

      }
      if(cont<k){
        printf("SIM\n");
      }
      else{
            printf("NAO\n");
            for(j=n-1;j>=0;j--){
                    if(v[j]<=0){

                        printf("%d\n",cont);
                        cont--;
                    }
            }


      }



}
