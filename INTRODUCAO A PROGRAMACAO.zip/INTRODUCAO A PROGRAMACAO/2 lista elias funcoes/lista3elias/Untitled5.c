#include<stdio.h>
int main(){
    int n , maior=0;
    int v[10000],i,ind;
     scanf("%d",&n);
     while(n!=0){
        for(i=0;i<n;i++){
            scanf("%d",&v[i]);
            if(v[i]>maior){
                maior=v[i];
                ind=i;
            }

            }
        printf("%d %d\n",ind,maior);
       // printf("digite um novo numero : ");
        scanf("%d",&n);
        i=0;
        maior=0;
    }


}
