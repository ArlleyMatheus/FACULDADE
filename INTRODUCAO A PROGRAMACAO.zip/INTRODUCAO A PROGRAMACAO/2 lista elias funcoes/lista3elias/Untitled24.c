#include<stdio.h>
int main(){
    int n,v[10000],maior=0,aux=0;
    scanf("%d",&n);
    while(n!=0){
            for(i=0;i<n;i++){
                scanf("%d",&v[i]);
                if(maior<v[i]){
                    maior=v[i];
                }
            }
            int v_count[maior+1];
            for(i=0;i<=maior){
                v_count[i]=aux;
            }

            for(i=0;i<maior;i++){
                v_count[v[i]]++;
            }
            for(i=0;i<maior){
                    v_vount[i]+=v_count-1;
            }
            for(int j=n-1;j>0;j--){
                    v[v_count[v[i]-1]=V[i].

            }






    }




}
