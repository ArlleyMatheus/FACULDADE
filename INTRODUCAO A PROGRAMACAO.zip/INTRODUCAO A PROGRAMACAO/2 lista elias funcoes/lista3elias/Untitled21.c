#include<stdio.h>
int main(){
    int n,i,j,cont=0,contador=1,cont1=0,aux=0;
    int v[100000];
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d",&v[i]);

    }
    for(i=1;i<=n-1;i++){
        for(j=i+1;j<=n;j++){
                if(v[i]>v[j]){
                    aux=v[i];
                    v[i]=v[j];
                    v[j]=aux;

                }
        }

    }
     for(i=1;i<=n;i++){
        if(v[i]%2==0){
            printf("%d\n",v[i]);

        }
     }
    for(j=n;j>0;j--){
        if(v[j]%2!=0){
            printf("%d\n",v[j]);
        }
    }


}





