#include<stdio.h>
int main (){
    int v[6],i,j,k,cont=0,ganhador=0,quadra=0,l=0,sena=0,nao_sena=0;
    int n,num[6];

    for(i=0;i<6;i++){
        scanf("%d",&v[i]);
    }
     scanf("%d",&n);
    while(n<1 ||n>500000){
        scanf("%d",&n);
    }


      int novo[n];

    for(i=0;i<n;i++){
            cont=0;
        for(j=0;j<6;j++){
                scanf("%d",&num[j]);
                while(num[j]<1 || num[j]>60){
                    scanf("%d",&num[j]);
                }
                while(num[j]==num[j-1]){
                    if(num[j]==num[j-1]){
                  //  printf("numero invalido digite novamente;\n");
                        scanf("%d",&num[j]);
                    }
                }
        }



        for(j=0;j<6;j++){
            for(k=0;k<6;k++){
                if(v[j] == num[k]){
                        cont=cont+1;
                        k=6;
                }
            }
              //printf("contador %d\n",cont);

        }
           novo[l]=cont;
            l++;
        }
     // for(i=0;i<n;i++){
          //  printf(" %d novo",novo[i]);
     // }


            for(i=0;i<n;i++){


                if(novo[i]>=6){
                        sena+=1;
                   // printf("Houve %d acertador(es) da sena\n",sena);

                }
                    if(nao_sena!=1){
                        if(novo[i]<6){
                          //  printf("Nao houve acertador para  sena\n");
                            nao_sena=1;
                        }
                    }


                        if(novo[i]==5){
                        ganhador+=1;
                           // printf("Houve %d acertador(es) da quina\n",ganhador);
                        }

                            if(novo[i]==4){
                            quadra+=1;
                              //  printf("Houve %d acertador(es) da quadra\n",quadra);
                            }
                }
               // printf("%d sena",sena);


                if(sena>=1){
                       // sena+=1;
                    printf("Houve %d acertador(es) da sena\n",sena);

                }
                else{
                    printf("Nao houve acertador para  sena\n");

                    }

                if(ganhador>=1){
                            //ganhador+=1;
                    printf("Houve %d acertador(es) da quina\n",ganhador);
                }
                else{
                    printf("Nao houve acertador para quina\n");
                }

                if(quadra>=1){
                            //quadra+=1;
                    printf("Houve %d acertador(es) da quadra\n",quadra);
                }
                else{
                    printf("Nao houve acertador para quadra\n");
                }



}











