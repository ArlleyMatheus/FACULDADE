
#include <stdio.h>
#include <math.h>

int next_power(int n, int p);

int closest(int next, int before, int pot, int n);

int main(){
    int n, pot;
    int res;
    int i;

    scanf("%d %d", &n, &pot);

    res = next_power(n, pot);
    for(i = 0;pow(i, pot) != res;i++);

    printf("%d -> %d^%d = %d\n", n, i, pot, res);
}

int next_power(int n, int pot){
    int i;
    int res;
    int next, ant;
    int proximo;

    for(i = 0;pow(i, pot) < n;i++);

    res = pow(i, pot);
    if(pow(i, pot) == n) return res;
    else{
        next = i;
        ant = i - 1;
        proximo = closest(next, ant, pot, n);
        res = pow(proximo, pot);
        return res;
    }
}

int closest(int next, int ant, int pot, int n){

    if(fabs(n - pow(next, pot)) < (n - pow(ant, pot))){
        return next;
    }
    else return ant;
}
