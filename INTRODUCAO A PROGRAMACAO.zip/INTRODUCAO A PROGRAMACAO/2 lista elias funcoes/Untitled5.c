#include<stdio.h>
#include<math.h>
int next_power(int n,int pot){
    int i=0,soma=0,cont=0,maior=0,menor=0;
    int resul=0;
    if (soma<n){
        while(soma <  n){
                if (soma < n){

                    soma = pow(i,pot);
                    i++;

                }
        }
    }else{
        while(soma <  n){
            if (soma < n){
                    soma = pow(i,pot);
                    i++;
            }
        }




    }

    maior = pow(i,pot) - n;
    menor = pow(i-1,pot);
    menor = n - menor;

    if(menor > maior){
        i = i-1;
        resul=pow(i,pot);
         return resul;
    }
    else{
        i=i-2;
        resul=pow(i,pot);
        return resul;
    }




}
int main (){
    int n,pot,res,i,maior=0,menor=0;
     double soma;
    //printf("digite o numero  e a potencia ");
    scanf("%d %d",&n,&pot);

    if(pot==0 ){
        printf("%d -> %d^%d = %d",n,n,pot,1);
    }
    else{
    res=next_power(n,pot);
      while(soma <  n){
            if (soma < n){

                soma = pow(i,pot);
                i++;

            }
    }

    maior = pow(i,pot) - n;
    menor = pow(i-1,pot);
    menor = n - menor;

  if(menor > maior){
        i = i-1;

    }
    else{
        i=i-2;
    }


    printf("%d -> %d^%d = %d\n",n,i,pot,res);


}
}
