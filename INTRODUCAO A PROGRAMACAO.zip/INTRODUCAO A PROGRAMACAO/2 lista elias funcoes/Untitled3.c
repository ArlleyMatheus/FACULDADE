#include<stdio.h>
int digit_count(long int n){
     int i=1,soma=0,div=n;
     if (i<= n){
        while(i<=n){
            if (i<=n){
                i=i*10;
                soma=soma+1;
            }
        }
    }
    else {
        while(i>=n){
            if (i>=n){
                    i*=-10;
                    soma+=1;

            }
        }
    }
    return soma;
}




int main (){
    int n,res ;
 //   printf("digite o numero : ");
    scanf("%ld",&n);
    res =  digit_count(  n );
    printf("Numero de digitos: %d\n",res);




}
