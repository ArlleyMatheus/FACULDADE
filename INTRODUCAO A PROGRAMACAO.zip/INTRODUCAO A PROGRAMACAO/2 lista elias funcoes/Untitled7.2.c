#include <stdio.h>

double compute_pi (int n) {
    int i;
    double num=2, den=1, result=1;

    for (i=1; i<= n; i++) {
        result = result *(num/den);
        if (i%2 == 0) {
            num=num+2;
        }
        else {
            den=den+2;
        }
    }

    return result*2;
}

int main() {
    int n;
    double resultado;

    scanf("%d", &n);

    resultado = compute_pi(n);

    printf("%.12lf\n", resultado);

    return 0;
}
