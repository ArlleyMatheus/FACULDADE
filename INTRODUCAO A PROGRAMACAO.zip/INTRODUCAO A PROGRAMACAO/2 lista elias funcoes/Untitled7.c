#include<stdio.h>
double compute_pi();
int main (){
    int n;
    double i,num=2,deno=1,soma1,soma2,soma3,ant,ant_d;
    printf("digite o numero ");
    scanf("%d",&n);
    for (i=0;i<n;i++){
           if( deno == ant_d){
            deno=deno+2;
           }
           else{

        printf("1 %lf/%lf\n",num,deno);

        soma1=num/deno;

         ant_d=deno+2;
        soma2=(num/ant_d)+soma1;
          printf("2 %lf/%lf\n",num,ant_d);

        num = ant+2;
        deno=ant_d*1;

           printf("3 %lf/%lf\n",num,deno);
        soma3=(num/deno)+soma2;

           }

        printf("%lf\n",soma3);

    }
}





