#include<stdio.h>
#include<string.h>
int main(){
                    //01 Combinador
  int n, i, j, k, contador, contador1, contador2;
  char string1[50], string2[50], nova[100];

  scanf("%d", &n);
  getchar();

  while(n){
    scanf("%s", string1);
    getchar();
    scanf("%s", string2);
    getchar();

    for(i = 0, contador1 = 0; string1[i] != '\0'; i++){
      contador1++;
    }
    for(i = 0, contador2 = 0; string2[i] != '\0'; i++){
      contador2++;
    }

    if(contador1 >= contador2){
      contador = (contador1 + contador2);
      for(i = 0, j = 0, k = 0; i < contador2*2; i++, j++, k++){
        nova[i] = string1[j];
        i++;
        nova[i] = string2[k];
      }
      for(; i < contador; i++, j++){
        if (contador1 > contador2) {
          nova[i] = string1[j];
        }
      }
    }
    if(contador2 > contador1){
      contador = (contador1 + contador2);
      for(i = 0, j = 0, k = 0; i < contador1*2; i++, j++, k++){
        nova[i] = string1[j];
        i++;
        nova[i] = string2[k];
      }
      for(; string2[j] != '\0'; i++, j++){
        nova[i] = string2[j];
      }
    }
//printf("Contador 1: %d\nContador 2: %d\n", contador1, contador2);
for(i = 0; i < contador; i ++){
  printf("%c", nova[i]);
}
printf("\n");
  n--;
  }
return 0;
}
