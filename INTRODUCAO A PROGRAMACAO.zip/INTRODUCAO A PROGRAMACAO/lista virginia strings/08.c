#include<stdio.h>
#include<string.h>

int main() {

  int i, j, primeira, segunda, verificador, cont;
  char frase[5000];

  while (scanf("%[^\n]", frase) != EOF) {
      cont = 0;
        getchar();

    for (i = 0; i < strlen(frase); i++) {
      if (frase[i] >= 'A' && frase[i] <= 'Z') {
        frase[i] += 32;
      }
    }
      for (i = 0, primeira = 0, verificador = 0, segunda = 0; i < strlen(frase); i++) {

      for (j = i; frase[j] != ' '; j++) {
      }
       if (frase[primeira] == frase[segunda] && segunda != 0 && segunda != primeira) {
        verificador++;
      }
       i = j + 1;

      segunda = i;

      if (frase[primeira] != frase[segunda]) {
        if (verificador > 0) {
          cont++;
          verificador = 0;
        }
      }

      if (frase[primeira] != frase[segunda]) {
        primeira = segunda;
      }
    }

    printf("%d\n", cont);
  }

}
