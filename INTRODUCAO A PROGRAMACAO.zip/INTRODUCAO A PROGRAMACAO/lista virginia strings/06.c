#include<stdio.h>
#include<string.h>

int main () {
                //06 Sequência Espelho
  int casos, i, j, n1, n2;
  char sequencia[12221];
  //Definir número de casos
  scanf("%d", &casos);
  //Loop conforme número de casos
  while (casos--) {
    //Definir valor inicial n1, e final n2
    scanf("%d %d", &n1, &n2);
    //Imprmir primeira sequencia
    for (i = n1; i <= n2; i++) {
      sprintf(sequencia, "%d", i);
      printf("%s", sequencia);
    }
    //Imprimir sequencia espelho
    for (i = n2; i >= n1; i--) {
      sprintf(sequencia, "%d", i);
      for (j = strlen(sequencia)-1; j >= 0; j--) {
        printf("%c", sequencia[j]);
      }
    }
    printf("\n");
  }
  return 0;
}
