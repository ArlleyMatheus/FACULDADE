#include<stdio.h>
#include<string.h>
int main(){
				//11 Frequência de Letras
	int casos, i, j, maior, testes[123], veremos;
	char frase[201], resultado[26];
	//Definir quantidade de casos testes
	scanf("%d", &casos);
	getchar();
	//Controle da execução dos casos testes
	while(casos--){
	//Ler a string frase
	scanf("%[^\n]", frase);
	//Consumir o '\n'
	getchar();
		//Transformar todas as letras em minúsuculas
		for (i = 0; i < strlen(frase); i++) {
			if (frase[i] >= 'A' && frase[i] <= 'Z') {
				frase[i] += 32;
			}
		}
		//Iniciar as posições de 97 a 122 com '0'
		for (i = 97; i <= 122; i++) {
			testes[i] = 0;
		}
		//Incrementar letra em 1 a cada aparição
		for(i = 0; i < strlen(frase); i++){
			if (frase[i] >= 'a' && frase[i] <= 'z') {
				testes[frase[i]]++;
			}
		}
		//Encontrar mais frequente
		for (i = 98, maior = 97; i <= 122; i++) {
			if (testes[i] > testes[maior]) {
				maior = i;
			}
		}
		//Escrever os maiores
		for (i = 97, j = 0, veremos = 0; i <= 122; i++) {
			if (testes[maior] == testes[i]) {
				resultado[j] = i;
				j++;
				veremos++; //variável incluída para não imprimir caracteres indesejados
			}
		}
	//for(i = 97; i <= 122; i++){
	//printf("Letra: %c Contador: %d\n", i, testes[i]);
	//}
	for (j = 0; j < veremos; j++) {
		printf("%c", resultado[j]);
	}
	printf("\n");
	//Reiniciar as posições da string resultado[i]
	for(i = 0; i < 200; i++){
	resultado[i] = '\0';
	}
	}
return 0;
}
