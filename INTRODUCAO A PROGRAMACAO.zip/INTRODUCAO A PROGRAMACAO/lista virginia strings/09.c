#include<stdio.h>
#include<string.h>
int main (){

  int casos, i, j, contador;
  char fraseA[10^4], fraseB[10^4];
  //Definir quantidade de casos
  scanf("%d", &casos);
  //Controle de casos
  while (casos--) {
    //Lê primeira String
    scanf("%s", fraseA);
    getchar();
    //Lê segunda String
    scanf("%s", fraseB);
    getchar();
    //RESOLUÇÃO DO PROBLEMA
    //Verificação letra a letra da String A e B
    for (i = 0, contador = 0; i < strlen(fraseA); i++) {
      //Executar contagem para fraseA menor que fraseB
      if (fraseA[i] < fraseB[i]) {
        for (j = i; fraseA[j] < fraseB[i];) {
          fraseA[j] = fraseA[j]+1;
          contador++;
        }
      }
      //Executar contagem para fraseA maior que fraseB
      if (fraseA[i] > fraseB[i]) {
        for (j = i; fraseA[j] < 'z';) {
          fraseA[j] = fraseA[j]+1;
          //Incrementa contador de avanços
          contador++;
        }
        //fraseA[j] recebe 'a' para continuar a contagem
        fraseA[j] = 'a';
        //fraseA[j] = 'a', então incrementa contador
        contador++;
        //Laço final que conta de 'a' até fraseB[i]
        for (;fraseA[j] < fraseB[i];) {
          fraseA[j] = fraseA[j]+1;
          //Incrementa contador de avanços
          contador++;
        }
      }
    }
    //Imprimir saída final
    printf("%d\n", contador);
  }
return 0;
}
//(Letra inicial + total caracteres - abs(letra inicial - letra desejada)) % total caracteres;
