#include<stdio.h>
#include<string.h>
int main(){
					//1024 Criptografia
	int i, casos, tam, aux, tam2;
	char senha[10003];

	scanf("%d", &casos);
	getchar();
	while(casos--){

	scanf("%[^\n]", senha);
	getchar();

		//Encontrar tamanho da string
		for(i = 0, tam = 0; senha[i] != '\0'; i++){
		tam++;
		}
		//Primeira passada, posição +3 para letras minúsculas e maiúsculas
		for(i = 0; i < tam; i++){
			if((senha[i] >= 65 && senha[i] <= 90) || (senha[i] >= 97 && senha[i] <= 122)){
		senha[i] = senha[i] + 3;
			}
		}
		//Segunda passada, inverter posições
		for(i = 0, tam2 = tam-1; i < tam/2; i++, tam2--){
		aux = senha[tam2];
		senha[tam2] = senha[i];
		senha[i] = aux;
		}
		//Terceira passada, posição -1 da metade em diante
		for(i = (tam/2); i < tam; i++){
			senha[i] -= 1;
		}
	//Imprimir criptografia
	printf("%s\n", senha);
	}
return 0;
}
