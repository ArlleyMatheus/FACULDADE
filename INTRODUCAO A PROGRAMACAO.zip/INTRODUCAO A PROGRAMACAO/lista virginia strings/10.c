#include<stdio.h>
#include<string.h>
int main(){
            //10 Sentença Dançante
  int i, j, k;
  char frase[51];
  //Entrada com final de arquivo
  while (scanf("%[^\n]", frase) != EOF) {
    //Consumir o '\n'
    getchar();
    //Transformar a primeira letra e maiúscula
    if (frase[0] >= 'a' && frase[0] <= 'z') {
      frase[0] -= 32;
    }
    //Percorrer todas as letras
    for (i = 0, j = 0, k = 1; j < strlen(frase); j++, k++) {
      //Retornar k para posição correta
      k = j + 1;
      //Ignorar espaço para comparação
      if (frase[k] == ' ') {
        for (; frase[k] == ' '; k++) {
        }
      }
      //Verificar minúsculas seguidas
      if (frase[j] >= 'a' && frase[j] <= 'z' && frase[k] >= 'a' && frase[k] <= 'z') {
        frase[k] -= 32;
      }
      //Verificar maiúsuculas seguidas
      if (frase[j] >= 'A' && frase[j] <= 'Z' && frase[k] >= 'A' && frase[k] <= 'Z') {
        frase[k] += 32;
      }
    }
    //Imprimir saída do problema
    printf("%s\n", frase);
  }
return 0;
}
