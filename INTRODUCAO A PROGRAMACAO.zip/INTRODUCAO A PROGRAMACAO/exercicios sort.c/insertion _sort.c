#include<stdio.h>
int main ()
{
    int v[5],au=0,ao;
    int i;



    for(i=0;i<5;i++){
        printf("digite %d  de  5 numeros",i+1);
        scanf("%d",&v[i]);

    }
       while (v[i]>v[i+1]){
        au=v[0];
        v[0]=v[i];
        v[i]=au;
 i++;
       }

while (v[i+1]>v[i]){
    ao=v[i+1];
v[i+1]=v[i];
v[i]=ao;
        }



for (i=0;i<=5;i++){

printf(" %d",v[i]);


}

}
