#include<stdio.h>
int main()
{

    int r4,r
}




}
