#include <stdio.h>
int main ()
{
    char  sex;
    scanf("%c",&sex);



if (sex=='M'){

    printf(" masculino ");

}
if (sex=='F')

{

    printf("feminimo");

}
if (sex=='t'){

    printf("transexual");
}





}
