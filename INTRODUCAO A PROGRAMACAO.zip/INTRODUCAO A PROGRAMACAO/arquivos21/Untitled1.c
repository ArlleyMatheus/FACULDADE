#include <stdio.h><math.h>
int main()
{
    float a;
    float b;
    float c;
    //printf("digite um valor para A :",a);
    scanf("%f",&a);
    //printf("digite um valor para B: ",b);
    scanf("%f",&b);
   // printf("digite um valor para C: ",c);
    scanf("%f",&c);

    printf("O VALOR DE DELTA E= %.2f\n",pow(b,2)-4*a*c);


    return 0;





}
