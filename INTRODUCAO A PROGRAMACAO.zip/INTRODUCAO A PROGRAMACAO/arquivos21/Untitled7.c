#include<math.h>
int main()
{
    float r;
    float al;
        scanf("%f",&r);
        scanf("%f",&al);
        printf("O VALOR DO CUSTO E = %.2f\n ",2*M_PI*r*(r+al)*100);
        return 0;


}
