#include<stdio.h>
int main()
{
    int  n ,n1,n2,n3,n4,n5,n6;


    //printf ("digite uma sequencia de 3 algarismos ");
    scanf("%d",&n);


    n1=(n%100)%10;
    n2=(n%100)/10;
    n3=n/100;
  n4=n2*3;
  n5=n1*5;
  n6=(n3+n4+n5)%7;
    printf("O NOVO NUMERO E = %d\n",(n*10)+n6);
    return 0;
}


