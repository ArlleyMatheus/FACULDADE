#include<stdio.h>
int main()
{
int din,d1,d2,d3,d4;
scanf("%d",&din);
d1=din/100;
d2=(din%100)/50;
d3=(din%100%50)/10;
d4=(din%100%50%10)/1;




if ("d1==0"){
        printf("NOTAS DE 100 = %d\n",d1);}
   else("d1!=0");{
   printf("NOTAS DE 50 = %d\n",d2);
if ("d2!=0"){
    printf("NOTAS DE 10 = %d\n",d3);
}
else("d3!=0");{
    printf("MOEDAS DE 1 = %d\n",d4);



}


}

return 0;


}






