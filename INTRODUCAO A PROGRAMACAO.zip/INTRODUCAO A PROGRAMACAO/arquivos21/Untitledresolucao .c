#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
  char tipo[12]; int conta; float valor, consumo;
	scanf("%d",&conta); scanf("%f",&consumo); scanf("%s",&tipo);
	if (strcmp(tipo,"RESIDENCIAL")==0){
		valor=(consumo*0.05 + 5.00);
	}
	if (strcmp(tipo,"COMERCIAL")==0){
		if (consumo <= 80){
			valor=500.00;
		}
		else{
			valor=(500.00+((consumo-80)*0.25));
		}
	}
	if (strcmp(tipo,"INDUSTRIAL")==0){
		if (consumo <= 100){
			valor=800.00;
		}
		else{
			valor=(800.00+((consumo-100)*0.04));
		}
	}
	printf("CONTA = %d\nVALOR DA CONTA = %.2f\n", conta, valor);
	return 0;
}
