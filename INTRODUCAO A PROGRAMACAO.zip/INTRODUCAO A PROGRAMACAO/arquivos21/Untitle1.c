
#include<stdio.h>

int main()
{

    int h,m,s;
   // printf("digites as horas : ",h);
    scanf("%d",&h);
    //printf("digite os minutos: ",m);
    scanf("%d",&m);
   // printf("digite os segundos:",s);
    scanf("%d",&s);


    printf("O TEMPO EM SEGUNDOS E = %d\n",h*3600+m*60+s);



    return 0;
}
