#include <stdio.h>
int main()
{

    float pf;
    float pd;
    float impo;


       //printf("digite o valor do preco/fabrica ",pf);
       scanf("%f",&pf);
     //  printf("digite o valor de porcentagem ",pd);
       scanf("%f",&pd);
     //  printf("digiteo valor do perc/impostos ",impo);
       scanf("%f",&impo);
       printf("O VALOR DO CARRO E = %.2f\n",pd/100*pf+impo/100*pf+pf);

       return 0;

}
