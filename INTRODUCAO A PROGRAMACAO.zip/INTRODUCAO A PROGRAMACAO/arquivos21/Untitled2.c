#include<stdio.h>
int main()
{
    float  far;
    float pol;
   // printf("insira a  temperatura : ",far),
    scanf("%f",&far);
   // printf("insira as  polegadas de  chuva : ",pol);
    scanf("%f",&pol);
    printf("O VALOR EM CELSIUS = %.2f\n",(5*far-160)/9);
    printf("A QUANTIDADE DE CHUVA E = %.2f\n",(pol*25.4));


    return 0;






}
