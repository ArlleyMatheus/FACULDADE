#include<math.h>
int main()
{

    float x1,x2,y1,y2,x3,y3;
    //printf("para descobrir a distancia entre  A e B \n");
   // printf("digite X1 ");
    scanf("%f",&x1);
    //printf("digite X2: ");
    scanf("%f",&y1);
    //printf("digite Y1: ");
    scanf("%f",&x2);
    //printf("digite Y2");
    scanf("%f",&y2);
    x3=  pow(x2,2)-2*x2*x1+pow(x1,2);
    y3=  pow(y2,2)-2*y2*y1+pow(y1,2);
    printf("A DISTANCIA ENTRE A e B = %.2f\n",sqrt(x3+y3));

    return 0;
}

