#include<math.h>
#include<stdio.h>
int main()


{
     float l1;
     float l2;
     float l3;
     float t;

    //printf("insira  o lado 1 do  triangulo ",l1);
     scanf("%f",&l1);
   // printf("insira o lado 2 do  triangulo ",l2);
    scanf("%f",&l2);
    //printf("insira o lado 3  do  triangulo ",l3);
    scanf("%f",&l3);
    t=(l1+l2+l3)/2;
    printf("A AREA DO TRIANGULO E = %.2f\n", sqrt(t*(t-l1)*(t-l2)*(t-l3)));

    return 0;

}
