#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct{
    int matricula;
    int dia ;
    int mes;
    int ano;
    char nome[200];
}ORDENACAO;
int ComparaDataNasc(ORDENACAO ant_aluno, ORDENACAO aluno ){

     if(ant_aluno.ano <= aluno.ano )
         return 1;
     else
        return 0;
    if (ant_aluno.mes <= aluno.mes)
        return 1;
    else
        return 0;
    if(ant_aluno.dia <= aluno.dia)
        return 1;
    else{
        return 0;
    }
}

int main (){
    int    i,quant,funcao;
  //  printf("digite o numero de alunos : ");
    scanf("%d",&quant);
    ORDENACAO aux;
    ORDENACAO alunos[quant];
    for(i=0;i<quant;i++){
        scanf("%d",&alunos[i].matricula);
        scanf("%d",&alunos[i].dia);
        scanf("%d",&alunos[i].mes);
        scanf("%d",&alunos[i].ano);
        getchar();
        scanf("%[^\n]s",alunos[i].nome);
        getchar();
    }
    int j;

    for(j=0;j<=quant-1;j++){
        for(i=j;i<quant;i++){
            funcao=ComparaDataNasc(alunos[j],alunos[i]);
            printf("%d\n",funcao);
            printf("%d e %d\n",alunos[i].dia,alunos[j].dia);

            if(funcao == 0){
                aux.matricula=alunos[i].matricula;
                aux.dia = alunos[i].dia;
                aux.mes = alunos[i].mes;
                aux.ano = alunos[i].ano;
                strcpy(aux.nome, alunos[i].nome);

                alunos[i].matricula = alunos[j].matricula;
                alunos[i].dia = alunos[j].dia;
                alunos[i].mes = alunos[j].mes;
                alunos[i].ano = alunos[j].ano;
                strcpy(alunos[i].nome,alunos[j].nome);

                alunos[j].matricula = aux.matricula;
                alunos[j].dia = aux.dia;
                alunos[j].mes = aux.mes;
                alunos[j].ano = aux.ano;
                strcpy(alunos[j].nome,aux.nome);
            }
        }
    }
     for(i=quant-1;i >=0;i--){
            printf("Matric.:  %d Nome:  %s Data Nasc:  %d/%d/%d\n",alunos[i].matricula,alunos[i].nome,alunos[i].dia,alunos[i].mes,alunos[i].ano);
    }

}




