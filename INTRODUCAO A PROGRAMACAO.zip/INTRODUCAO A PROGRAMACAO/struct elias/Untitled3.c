#include<stdio.h>
#include<math.h>
typedef struct {
    float a ;
    float b ;
    float c ;
    float d ;
}A;
int main(){
    int i,n;
    float distancia=0,soma=0;
     scanf("%d",&n);
    A p[n];
     for(i=0;i<n;i++){
        scanf("%f",&p[i].a);
        scanf("%f",&p[i].b);
        scanf("%f",&p[i].c);
        scanf("%f",&p[i].d);
     }
      for(i=0;i<n-1;i++){
            distancia=sqrt((pow(p[i].a-p[i+1].a,2))+(pow(p[i].b-p[i+1].b,2))+(pow(p[i].c-p[i+1].c,2))+(pow(p[i].d-p[i+1].d,2)));
            soma+=distancia;
            printf("%.2f\n",soma);
            soma=0;
    }
}
