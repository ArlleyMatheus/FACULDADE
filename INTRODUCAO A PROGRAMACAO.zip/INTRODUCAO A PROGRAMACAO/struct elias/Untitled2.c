#include<stdio.h>
#include<math.h>
#include<stdlib.h>
typedef struct{
    float a;
    float b;
    float c;
    float d;

}ORDENA;

int main (){

    int tamanho,i;
    float *normas;
    normas = (float*)malloc(sizeof(float)*tamanho);

    printf("digite o tamanho : ");
    scanf("%d",&tamanho);
      ORDENA vetor[tamanho];

    for(i=0;i<tamanho;i++){
        scanf("%f",&vetor[i].a);
        scanf("%f",&vetor[i].b);
        scanf("%f",&vetor[i].c);
        scanf("%f",&vetor[i].d);
        normas[i]=sqrt((vetor[i].a*vetor[i].a)+(vetor[i].b*vetor[i].b)+(vetor[i].c*vetor[i].c)+(vetor[i].d*vetor[i].d));
    }
    int j;
    float aux=0,aux2=0;
    for(i=0;i<tamanho-1;i++){
        for(j=i+1;j<tamanho;j++){
            if(normas[i]>normas[j]){
               aux=normas[i];
               normas[i]=normas[j];
               normas[j]=aux;
            }
        }
        if(i<tamanho-1){
              printf("Vetor:(%.2f,%.2f,%.2f,%.2f) Norma: %.2f\n",vetor[i].a,vetor[i].b,vetor[i].c,vetor[i].d,normas[i]);
        }
        else{
              printf("Vetor:(%.2f,%.2f,%.2f,%.2f) Norma: %.2f\n",vetor[j].a,vetor[j].b,vetor[j].c,vetor[j].d,normas[j]);
        }
    }

}





