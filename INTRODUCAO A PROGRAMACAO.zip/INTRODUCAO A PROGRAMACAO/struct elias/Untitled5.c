#include<stdio.h>
int main(){
    int quant;
    char sinal




}
