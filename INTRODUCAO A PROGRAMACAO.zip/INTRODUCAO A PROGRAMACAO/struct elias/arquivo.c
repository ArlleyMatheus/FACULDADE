#include<stdio.h>
int main(){
    FILE *arq;
    arq=fopen("arquivo.txt","w");
    fprintf(arq,"arlley e bonitao");
    fclose(arq);


}
