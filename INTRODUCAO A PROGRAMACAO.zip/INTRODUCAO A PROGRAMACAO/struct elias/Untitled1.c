#include<stdio.h>
#include<string.h>
typedef struct {
    int codigo;
    float valor_credito;
    char nome_curso[100];

}TIPO_CURSOS;

typedef struct {
    char nome_aluno[500];
    int codigo ;
    int credito;

}TIPO_ALUNO;





int main (){
    int nalunos,mcursos,i,j;
    TIPO_CURSOS cursos[30];
    TIPO_ALUNO aluno[1000];

 //   printf("digite a quantidade de cursos : ");
    scanf("%d",&mcursos);
    for(i=0;i<mcursos;i++){
   //     printf("digite o codigo do curso : ");
        scanf("%d",&cursos[i].codigo);
     //   printf("digite o valor de creditos : ");
        scanf("%f",&cursos[i].valor_credito);
       // printf("digite o nome do curso ");
        getchar();
        scanf("%[^\n]",cursos[i].nome_curso);
        getchar();
    }
   // printf("digite a quantidade de alunos : ");
    scanf("%d",&nalunos);
    getchar();
    for(j=0;j<nalunos;j++){
     //   printf("digite o nome do aluno : ");
        scanf("%[^\n]",aluno[j].nome_aluno);
        getchar();
       // printf("digite o codigo o curso  do aluno : ");
        scanf("%d",&aluno[j].codigo);
        //printf("digite o numero de creditos : ");
        scanf("%d",&aluno[j].credito);
         getchar();
    }


     for(i=0;i<=mcursos;i++){
            for(j=0;j<nalunos;j++){

                if(aluno[i].codigo == cursos[j].codigo){
                     printf("Aluno(a):  %s",aluno[i].nome_aluno);
                     printf(" Curso:  %s Num.",cursos[j].nome_curso);
                     printf("  Creditos:  %d ",aluno[i].credito);
                     printf("Valor Credito:  %.2f ",cursos[j].valor_credito);
                     printf("Mensalidade:  %.2f\n",cursos[j].valor_credito*aluno[i].credito);
                }


            }
     }
    return 0;
}
