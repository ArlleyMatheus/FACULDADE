#include<stdio.h>
int main()
{
    int h;
    int h1;

    scanf("%d",&h);
     h1=((h/3)*10+(h%3)*5);
    if(h<3){
        printf("O VALOR A PAGAR E = %d.00\n",h*5);
    }
        else{
    printf("O VALOR A PAGAR E = %d.00\n",h1);
    return 0;

        }


    }










