#include<stdio.h>
int main()
{
    float sal,sal1=0,sal2=0;
  scanf("%f",&sal);



    if (sal<=300){

            printf("SALARIO COM REAJUSTE = %.2f\n",(0.5*sal)+sal);}

       else {

        printf("SALARIO COM REAJUSTE = %.2f\n",(0.3*sal)+sal);

return 0;
    }








}
