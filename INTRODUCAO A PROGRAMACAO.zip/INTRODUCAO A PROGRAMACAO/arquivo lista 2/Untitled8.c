#include <stdio.h>
int main ()

{
int n  ,n2,n3,n4,cont,menor=0 ;
while(cont<=2){
cont++;
   // printf("digite um numero ");
    scanf("%d",&n);
    scanf("%d",&n2);
    scanf("%d",&n3);
    scanf("%d",&n4);
    cont++;
    menor=n;
        if (n2<menor){
                menor=menor+n2;

         }
             if(n3<menor){
                menor=menor+n3;
             }


}
printf ("%d\n",menor);
return 0;
}



