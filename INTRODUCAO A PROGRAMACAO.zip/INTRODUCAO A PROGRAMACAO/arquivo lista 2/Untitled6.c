#include <stdio.h>
 #include <math.h>
int main()
{
    float a,b,c,x2,x1;
     float delta;
    scanf("%f%f%f",&a,&b,&c);



    delta=sqrt((b*b)-4*a*c);
    x1=(-b+delta)/(2*a);
     x2=(-b-delta)/(2*a);



if (delta>0){
    printf("RAIZES DISTINTAS\n");
    printf("X1 = %.2f\n",x1);
    printf("X2 = %.2f\n",x2);}
    if(delta==0)
    {
        printf("RAIZ UNICA\n");
        printf("X1 = %.2f\n ",x1);}
         else
            {
            printf("RAIZES IMAGINARIAS\n");


return 0;
        }

}






