#include<stdio.h>
int main ()
{
    int conta  ;
    float custo;
    char tipo;

           // printf ("digite a conta o custo e o tipo");
            scanf("%d %f %c",&conta,&custo,&tipo);

                    if(tipo == 'R'){
                    printf(" CONTA = %d\n",conta);
                    printf(" VALOR DA CONTA = %.2f\n",(custo*0.05)+5.00 );}

                                if(tipo == 'C'){
                                  printf(" CONTA = %d\n",conta);
                                printf(" VALOR DA CONTA = %.2f\n",(500)+(custo-80)*0.25);}

                                                    if(tipo == 'I'){

                                                printf(" CONTA = %d\n",conta);
                                                printf(" VALOR DA CONTA = %.2f\n",(800)+(custo-100)*0.04);}
                                            return 0;


}









