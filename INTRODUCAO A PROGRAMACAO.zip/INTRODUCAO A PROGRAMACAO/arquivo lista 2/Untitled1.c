#include<stdio.h>
int main(){
    float n1,n2,n3,MEDIA;
    printf("digite AS NOTAS ");
    scanf("%f %f %f",&n1,&n2,&n3);

   printf("%.1f %.1f %.1f",n1,n2,n3);
    printf(" MEDIA  =%.2f\n",(n1+n2+n3)/3);

     if( MEDIA >=6){
        printf(" APROVADO ");
        }else {
          printf("REPROVADO");}



     return 0;






}








