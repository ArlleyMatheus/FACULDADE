#include<stdio.h>
int main()
{
    float a,b,c;

     scanf("%f%f%F",&a,&b,&c);
     if (((b-c)<a<+c)&& ((a-c)<b<a+c) && ((a-b)<c<a+b)){

        printf(" PERIMETRO = %f\n",a+b+c);

     }
                else {
                    printf("% AREA %f\n",((a+b)*c)/2);
                }


}
