#include<stdio.h>
int main ()
{

    int n1,n2,n3;

     scanf("%d",&n1);
  n2=n1%3;
  n3=n1%5;
   if (n2==0&&n3==0)
   printf("O NUMERO E DIVISIVEL \n");
   else
   printf("O NUMERO NAO E DIVISIVEL \n");

return 0;
}
