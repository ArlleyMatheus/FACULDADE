#include <stdio.h>
int main ()
{
    int v[10000],n,i,maior=0,soma=0;
      printf("digite um numero : ");
      scanf("%d",&n);
      for(i=0;i<n;i++){
   printf("igite um numero para %d: ",i+1);
        scanf("%d",&v[i]);
        if (maior<=v[i]){
            maior=v[i];
              if ( v[i]==maior){
                        soma =soma+1;}}}

                         printf("o numero %d esta na poscicao %d e apareceu %d",maior,i+1,soma);}












