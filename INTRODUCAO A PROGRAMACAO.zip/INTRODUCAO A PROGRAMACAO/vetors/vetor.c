#include<stdio.h>
int main ()
{
  int v[5000],n,i;
  //printf("digite o tamanho do numero :  ");
   scanf("%d",&n);
    for (i=0;i<n;i++){
           // printf("digite  o %d numero de  %d:  ",i+1,n);
            scanf("%d",&v[i]);
    }
    for(i=n-1;i>=0;i--){
        printf("%d ",v[i]);
    }

return 0;
}











