#include<stdio.h>
int main (){
    int v[5000],n,i,maior=0,soma =0,j=0;
    printf("digite o tamnho do vetor : ");
    scanf("%d",&n);
    for (i=0;i<n;i++){
        printf("digite um numero  %d : ",i+1);
        scanf("%d",&v[i]);
             if (maior < v[i])
                     maior = v[i];}
                     for (i=0 ;i<=maior;i++){
                        if (i<=v[i]){
                            soma=soma+1;
                        }


                     }
                      for (i=0;i<=maior;i++){
                                printf("%d=%d\n",i,soma);



                    }}








