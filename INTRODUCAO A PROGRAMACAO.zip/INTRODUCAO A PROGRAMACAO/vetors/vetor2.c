#include <stdio.h>
int main()
{
    int v[5000],n,i;

     //printf("digite  o tamanho  do numero : ");
     scanf("%d",&n);
    for (i=0;i<n;i++){
        //printf ("digite o numero : ");
        scanf("%d",&v[i]);}
       for (i=0;i<n;i++){
        printf("%d ",v[i]);
       }
return 0;
    }





