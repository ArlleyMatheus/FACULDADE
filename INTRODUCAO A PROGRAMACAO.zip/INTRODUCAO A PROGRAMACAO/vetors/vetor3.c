#include <stdio.h>
int main ()
{
    int v[5000],n,i,soma=0;

          //printf("digite um numero : ");
          scanf("%d",&n);
          for (i=0;i<n;i++){
            //printf("digite um numero: ");
            scanf("%d",&v[i]);
soma =v[i]+soma;}
printf("%d",soma );


return 0;


}
