
    FILE *arq=NULL;
    FORNECEDOR aux;
    char cnpj[20];
    int tam;

    printf("digite o cnpj do forncedro a ser excluido\t");
    scanf(" %s",cnpj);
   // system("sleep 1");

    arq=fopen("fornecedor.txt","rb+");

    do{
        fread(&aux,sizeof(FORNECEDOR),1,arq);
        if( strcmp(aux.cnpj,cnpj)==0 ){
            fseek(arq,1,SEEK_CUR);

            while(!feof(arq)){
                fseek(arq,-1,SEEK_CUR);

                fread(&aux,sizeof(FORNECEDOR),1,arq );
                fseek(arq,-2*sizeof(FORNECEDOR),SEEK_CUR);
                fwrite(&aux, sizeof(FORNECEDOR),1,arq);
                fseek(arq,sizeof(FORNECEDOR),SEEK_CUR);

                fseek(arq,1,SEEK_CUR);
            }
           // tam=ftell(arq);
           // truncate( arq, tam-sizeof(FORNECEDOR));

        }

    }while(!feof(arq));

    fclose(arq);
