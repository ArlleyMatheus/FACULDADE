#include<stdio.h>
typedef struct{
     float numerador;
     float denominador;



}FRACAO;


int main (){
    int casos,quant=1,i=1,j,cont=0;

    int quant_repeticoes=0;
    FRACAO *fracao;
    fracao=malloc(sizeof(FRACAO)*i);
    scanf("%d",&casos);
    while(quant<=casos){
            do{
                quant_repeticoes++;
                i++;
                 fracao = (FRACAO*)malloc(sizeof(FRACAO)*i);
                 printf("%.0f/%.0f",fracao[i].numerador,&fracao[i].denominador);

            }while(scanf("%f/%f",&fracao[i].numerador,&fracao[i].denominador)== '\0');

            printf("Caso de teste %d\n",quant);
            for(i=0;i<=quant_repeticoes;i++){
                for(j=i+1;j<quant_repeticoes;j++){
                        if(fracao[i].numerador/fracao[i].denominador == fracao[j].numerador/fracao[j].denominador){
                            printf("%.0f/%.0f equivalente a %0.f/%0.f\n",fracao[i].numerador,fracao[i].denominador,fracao[j].numerador,fracao[j].denominador);
                            cont=1;
                        }
                }
            }
            if(cont==0){
                printf("Nao ha fracoes equivalentes na sequencia\n");
            }
            cont=0;
        quant++;
    }
}
