#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
typedef struct{
        int numero;
        char descricao[50];
        int ano;
        float valor_compra;
        char situacao;
        char sigla[10];
}PATRIMONIO;
typedef struct {
    char sigla_dep[10];
    char nome[30];
}DEPARTAMENTO;


void incluir_patrimonio();
void listar_patrimonio();
void consultar_patrimonio();
void excluir_patrimonio();
void alterar_patrimonio();
void incluir_departamento();
void listar_departamento();
void consultar_departamento();
void excluir_departamento();
void alterar_departamento();
int main (){
    int opcao_cadastro,opcao_1=0,opcao_2=0;
    do{

        printf("1 CADASTRO BEM_PATRIMONIO\n");
        printf("2 CADASTRO DEPARTAMENTO\n");
        printf("3 LISTAR BEM_PATRIMONIO AGRUPADO POR DEPARTAMENTO\n");
        printf("4 SAIR\n");
        printf("\n\nDIGITE UMA OPCAO: ");
        scanf("%d",&opcao_cadastro);
        system("cls");
        switch(opcao_cadastro){
            case 1:
                do{
                    printf("  1-INCLUIR BEM_PATRIMONIO\n");
                    printf("  2-CONSULTAR BEM_PATRIMONIO\n");
                    printf("  3-LISTAR BEM_PATRIMONIO\n");
                    printf("  4-EXCLUIR BEM_PATRIMONIO\n");
                    printf("  5-ALTERAR BEM_PATRIMONIO \n");
                    printf("  6-VOLTAR\n");
                    printf("\n\nDIGITE UMA OPCAO: ");
                    scanf("%d",&opcao_1);
                    system("cls");

                    switch(opcao_1){
                        case 1:
                            incluir_patrimonio();
                        break;
                        case 2:
                            consultar_patrimonio();
                        break;
                        case 3:
                            listar_patrimonio();
                        break;
                        case 4:
                             excluir_patrimonio();
                        break;
                        case 5:
                             alterar_patrimonio();
                        break;
                        default :
                            printf("OPCAO INVALIDA !\n");
                            break;
                    }
                }while(opcao_1 !=6 );
                system("cls");
                break;

            case 2:
                 system("cls");
                do{
                    printf("  1-INCLUIR DEPARTAMENTO\n");
                    printf("  2-CONSULTAR DEPARTAMENTO\n");
                    printf("  3-LISTAR DEPARTAMENTO\n");
                    printf("  4-EXCLUIR DEPARTAMENTO\n");
                    printf("  5-ALTERAR DEPARTAMENTO \n");
                    printf("  6-VOLTAR\n");
                    printf("\n\nDIGITE UMA OPCAO: ");
                    scanf("%d",&opcao_2);
                     system("cls");


                      switch(opcao_2){
                        case 1:
                            incluir_departamento();
                        break;
                        case 2:
                            consultar_departamento();
                        break;
                        case 3:
                            listar_departamento();
                        break;
                        case 4:
                            excluir_departamento();
                        break;
                        case 5:
                            alterar_departamento();
                        break;
                    }

                }while(opcao_2!=6);
                  system("cls");
                  break;

            case 3:
                listar_fornecedor_area();
            break;

            case 4:
                opcao_2=6;
            break;

            default:
                printf("OPCAO INVALIDA !\n");
            break;
    }
    }while(opcao_cadastro!=4);

}
void incluir_patrimonio(){
    FILE *arquivo;
    int i=0,j=0,variavel=0;
    int cont=0;
    PATRIMONIO *patrimonio;
    PATRIMONIO patrimonio1;
    patrimonio=(PATRIMONIO*)malloc(sizeof(PATRIMONIO)*1);

    if(arquivo=fopen("bempatrimonial.dat","rb")==NULL){
        do{
            printf("DIGITE O  NUMERO  DO BEM PATRIMONIAL: ");
            scanf("%d",&patrimonio[i].numero);
            if(i!=0){
                for(j=0;j<i;j++){
                    while(patrimonio[i].numero==patrimonio[j].numero){
                        printf("\n\t\tBEM PATRIMONIAL JA CADASTRADO!");
                        printf("\n\n\t\tDIGITE UM NUMERO DO BEM PATRIMONIAL: ");
                        scanf("%d",&patrimonio[i].numero);
                    }
                }
            }
            printf("\nDIGITE O ANO: ");
            scanf("%d",&patrimonio[i].ano);
            printf("\nDIGITE O VALOR DA COMPRA: ");
            scanf("%f",&patrimonio[i].valor_compra);
            getchar();
            printf("\nDIGITE A  SITUACAO (I)PARA INCORPORADO E (B) PARA BAIXADO: ");
            scanf("%c",patrimonio[i].situacao);
            getchar();
            printf("DIGITE A SIGLA DO DEPARTAMENTO: ");
            scanf("%[^\n]s",patrimonio[i].sigla);
            getcha();
            i++;
            cont++;
            printf("DIGITE UM PARA FAZER 1 PARA REALIZAR NOVO CADASTRO 0 PARA SAIR: ");
            scanf("%d",&variavel);
            if(variavel==1)
                 patrimonio=(PATRIMONIO*)malloc(sizeof(PATRIMONIO)*1);
        }while(variavel!=0);
        arquivo=fopen("bempatrimonial.dat","ab");
        if(arquivo==NULL)
            printf("Arquivo nao pode ser aberto");
        else{
                for(i=0;i<cont;i++){
                    patrimonio1=patrimonio[i];
                    fwrite(&patrimonio1,sizeof(PATRIMONIO),1,arquivo);
                }
        }
    }
    else{
        while(fread(&patrimonio1,sizeof(PATRIMONIO),1,arquivo)==1){
            patrimonio[i]=patrimonio1;
            i++;
            cont++;
        }
         do{
            printf("DIGITE O  NUMERO  DO BEM PATRIMONIAL: ");
            scanf("%d",&patrimonio[i].numero);
            if(i!=0){
                for(j=0;j<i;j++){
                    while(patrimonio[i].numero==patrimonio[j].numero){
                        printf("\n\t\tBEM PATRIMONIAL JA CADASTRADO!");
                        printf("\n\n\t\tDIGITE UM NUMERO DO BEM PATRIMONIAL: ");
                        scanf("%d",&patrimonio[i].numero);
                    }
                }
            }
            printf("\nDIGITE O ANO: ");
            scanf("%d",&patrimonio[i].ano);
            printf("\nDIGITE O VALOR DA COMPRA: ");
            scanf("%f",&patrimonio[i].valor_compra);
            getchar();
            printf("\nDIGITE A  SITUACAO (I)PARA INCORPORADO E (B) PARA BAIXADO: ");
            scanf("%c",patrimonio[i].situacao);
            getchar();
            printf("DIGITE A SIGLA DO DEPARTAMENTO: ");
            scanf("%[^\n]s",patrimonio[i].sigla);
            getcha();
            i++;
            cont++;
            printf("DIGITE UM PARA FAZER 1 PARA REALIZAR NOVO CADASTRO 0 PARA SAIR: ");
            scanf("%d",&variavel);
            if(variavel==1)
                 patrimonio=(PATRIMONIO*)malloc(sizeof(PATRIMONIO)*1);
        }while(variavel!=0);
        arquivo=fopen("bempatrimonial.dat","wb");
        if(arquivo==NULL)
            printf("Arquivo nao pode ser aberto");
        else{
                for(i=0;i<cont;i++){
                    patrimonio1=patrimonio[i];
                    fwrite(&patrimonio1,sizeof(PATRIMONIO),1,arquivo);
                }
        }
    }
}
void listar_departamento(){





}
void listar_patrimonio();
void consultar_patrimonio()
void excluir_patrimonio();
void alterar_patrimonio();
void incluir_departamento();
void listar_departamento();
void consultar_departamento();
void excluir_departamento();
void alterar_departamento();
