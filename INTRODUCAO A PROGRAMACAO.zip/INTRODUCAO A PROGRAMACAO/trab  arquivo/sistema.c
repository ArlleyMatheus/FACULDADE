#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#define TAM 100



typedef struct {
    char cnpj[30];
    char nome[200];
    float capital_social;
    char nome_representante[200];
    char telefone[20];
    int ano;
    char situacao;
    int cod_area;
} FORNECEDOR;

typedef struct{
    int codigo;
    char nome[200];

} AREA;

void incluir_fornecedor();
void listar_fornecedor();
void printar_fornecedor(FORNECEDOR cadastro);
void incluir_area();
void listar_area();
void  consultar_fornecedor();
void consulta_cnpj();
void consulta_nome();
void excluir_fornecedor();
void consulta_nome_area();
void consulta_codigo();
void excluir_area();
void alterar_fornecedor();
void alterar_area();
void listar_fornecedor_area();




int main (){
    int opcao_cadastro,opcao_1=0,opcao_2=0;
    FORNECEDOR cadastro;




    do{
        printf("\t\t\t\tPROGRAMA COMPRAS \n***************************************************************************\n\n\n\n");
        printf("1 CADASTRO FORNECEDOR\n");
        printf("2 CADASTRO AREA\n");
        printf("3 LISTAR FORNECEDOR AGRUPADO COM AREA \n");
        printf("4 SAIR\n");
        printf("\n\nDIGITE UMA OPCAO: ");
        scanf("%d",&opcao_cadastro);
        system("cls");
        switch(opcao_cadastro){

            case 1:


                do{
                    cabecalho();
                    printf("  1-INCLUIR FORNECEDOR\n");
                    printf("  2-CONSULTAR FORNECEDOR\n");
                    printf("  3-LISTAR FORNECEDOR\n");
                    printf("  4-EXCLUIR FORNECEDOR\n");
                    printf("  5-ALTERAR FORNECEDOR \n");
                    printf("  6-VOLTAR\n");
                    printf("\n\nDIGITE UMA OPCAO: ");
                    scanf("%d",&opcao_1);
                    system("cls");

                    switch(opcao_1){
                        case 1:
                            incluir_fornecedor();
                        break;
                        case 2:
                            consultar_fornecedor();
                        break;
                        case 3:
                            listar_fornecedor();
                        break;
                        case 4:
                             excluir_fornecedor();
                        break;
                        case 5:
                             alterar_fornecedor();
                        break;
                        default :
                            printf("OPCAO INVALIDA !\n");
                            break;

                    }
                }while(opcao_1 !=6 );

                system("cls");
                break;

            case 2:
                 system("cls");
                do{
                    printf("\t\t\t\tCADASTRO AREA\n");
                    printf(" ******************************************************************** \n");
                    printf("  1-INCLUIR AREA \n");
                    printf("  2-CONSULTAR AREA\n");
                    printf("  3-LISTAR AREA\n");
                    printf("  4-EXCLUIR AREA\n");
                    printf("  5-ALTERAR AREA \n");
                    printf("  6-VOLTAR\n");
                    printf("\n\nDIGITE UMA OPCAO: ");
                    scanf("%d",&opcao_2);
                     system("cls");


                      switch(opcao_2){
                        case 1:
                            incluir_area();
                        break;
                        case 2:
                            consultar_area();
                        break;
                        case 3:
                            listar_area();
                        break;
                        case 4:
                            excluir_area();
                        break;
                        case 5:
                            alterar_area();
                        break;
                    }

                }while(opcao_2!=6);
                  system("cls");
                  break;

            case 3:
                listar_fornecedor_area();
            break;

            case 4:
                opcao_2=6;
            break;

            default:
                printf("OPCAO INVALIDA !\n");
            break;
    }
    }while(opcao_cadastro!=4);

    int i,k,j;
    char sd,se;
    system("cls");
    sd='*';
    se='%';

        for(i=0;i<4;i++){
            for(k=1;k<5;k++){
                for(j=1;j<=40-(2*i+k);j++)
                    printf(" ");
                    printf("/");
                    for(j=1;j<(2*i+k);j++)
                        printf("%c",se);
                         for(j=1;j<(2*i+k);j++)
                        printf("%c",sd);
                    printf("\\\n");
            }
        }
        for(i=0;i<2;i++)
        {
            for(j=0;j<38;j++)
                printf(" ");
                printf("| |\n");
        }
        printf("\n");;
        for(j=0;j<35;j++)
            printf(" ");
        printf("FELIZ NATAL\n");
        printf("\n\n\n\n\n\n");


        j=0;
        int l=2;
        while(j<=17){

            for(k=0;k<10999559;k++);
            switch(j){
                case 1:
                    printf("\t\t\t      E");
                    break;
                case 2:
                      printf("N");
                break;
                case 3:
                      printf("C");
                break;
                case 4:
                      printf("E");
                break;
                case 5:
                      printf("R");
                break;
                case 6:

                      printf("R");
                break;
                case 7:
                      printf("A");
                break;
                case 8:
                      printf("N");
                break;
                case 9:
                      printf("D");
                break;
                case 10:
                      printf("O");
                break;
                case 11:
                      printf("  ");
                break;
                case 12:
                      printf("S");
                break;
                case 13:
                      printf("E");
                break;
                case 14:
                      printf("S");
                break;
                case 15:
                      printf("S");
                break;
                case 16:
                      printf("A");
                break;
                case 17:
                      printf("0\n\n\n\n");
                break;
            }

            j++;
            l+=3;
            }
            getchar();


        }







    //FIM DO INT MAIN









incluir_fornecedor(){
       int i=0,cont=0,j=0,quant,decisao=1;
       FILE *fornecedor;
       FORNECEDOR cadastro;
       FORNECEDOR cadastro1[TAM];
       cabecalho();


    fornecedor=fopen("fornecedor.txt","rb");
    if(fornecedor == NULL){
        while(decisao!=0){

            getchar();
            printf("DIGITE O CNPJ: ");
            scanf(" %[0-9]{2}\.?[0-9]{3}\.?[0-9]{3}\/?[0-9]{4}\-?[0-9]{2}",cadastro1[i].cnpj);
            printf("\n");
           getchar();
           if(i!=0){
                for(j=0;j<i;j++){
                        while(strcmp(cadastro1[i].cnpj,cadastro1[j].cnpj)==0){
                            printf("\t\t\n\nCADASTRO INVALIDO\n\n");
                            printf("\n\nDIGITE O CNPJ: ");
                            scanf(" %[0-9]",cadastro1[i].cnpj);
                            printf("\n");
                           getchar();
                           system("cls");
                        }
                }
           }


            printf("DIGITE O NOME DO FORNECEDOR : ");
            scanf("%[^\n]s", cadastro1[i].nome);
             printf("\n");
            getchar();
            printf("DIGITE O CAPITAL SOCIAL : ");
            scanf("%f",&cadastro1[i].capital_social);
             printf("\n");
            getchar();
            printf("DIGITE O NOME DO REPRESENTANTE: ");
            scanf("%[^\n]",cadastro1[i].nome_representante);
             printf("\n");
            getchar();
            printf("DIGITE O TELEFONE: ");
            scanf("%s",cadastro1[i].telefone);
             printf("\n");
            getchar();
            printf("DIGITE O ANO : ");
            scanf("%d",&cadastro1[i].ano);
            printf("\n");
            getchar();
            printf("DIGITE A SITUACAO  (A) PARA ATIVO  E (I) PARA INATIVO: ");
            scanf("%c",&cadastro1[i].situacao);
             printf("\n");
            getchar();
            printf("DIGITE O CODIGO DA  AREA : ");
            scanf("%d",&cadastro1[i].cod_area);
             printf("\n");
             i++;
             cont++;
            printf("\n\n\t\tCadastro realizado\n\n");
            printf("\t\t\t\tDIGITE 1 PARA CONTINUAR E 0 PARA SAIR:  ");
            scanf("%d",&decisao);
            system("cls");
        }
        fornecedor=fopen("fornecedor.txt","ab");
        if(fornecedor==NULL){
            printf("Arquivo nao pode ser aberto..");
       }
    else{
            for(i=0;i<cont;i++){
                cadastro=cadastro1[i];
                fwrite(&cadastro,sizeof(FORNECEDOR),1,fornecedor);
            }
        fclose(fornecedor);
        system("cls");
    }
}

    else{

         while(fread(&cadastro,sizeof(FORNECEDOR),1,fornecedor)==1){
            cadastro1[i]=cadastro;
            cont++;
            i++;
         }
         fclose(fornecedor);


            do{

                getchar();
                printf("DIGITE O CNPJ: ");
                scanf(" %[0-9]",cadastro1[i].cnpj);
                printf("\n");
               getchar();

               if(i!=0){
                    for(j=0;j<i;j++){
                            while(strcmp(cadastro1[i].cnpj,cadastro1[j].cnpj)==0){
                                 printf("INVALIDO \n\n\n\t\t\tCODIGO JA EXISTENTE!!\n\n\n\n");
                                printf("DIGITE UM NOVO CODIGO : ");
                                scanf(" %[0-9]",cadastro1[i].cnpj);
                                printf("\n");
                               getchar();
                               system("cls");
                            }
                    }
               }


                printf("DIGITE O NOME DO FORNECEDOR : ");
                scanf("%[^\n]s", cadastro1[i].nome);
                 printf("\n");
                getchar();
                printf("DIGITE O CAPITAL SOCIAL : ");
                scanf("%f",&cadastro1[i].capital_social);
                 printf("\n");
                getchar();
                printf("DIGITE O NOME DO REPRESENTANTE: ");
                scanf("%[^\n]",cadastro1[i].nome_representante);
                 printf("\n");
                getchar();
                printf("DIGITE O TELEFONE: ");
                scanf("%s",cadastro1[i].telefone);
                 printf("\n");
                getchar();
                printf("DIGITE O ANO : ");
                scanf("%d",&cadastro1[i].ano);
                printf("\n");
                getchar();
                printf("DIGITE A SITUACAO  (A) PARA ATIVO  E (I) PARA INATIVO: ");
                scanf("%c",&cadastro1[i].situacao);
                 printf("\n");
                getchar();
                printf("DIGITE A COD AREA : ");
                scanf("%d",&cadastro1[i].cod_area);
                 printf("\n");
                 i++;
                 cont++;
                 printf("\n\n\t\tCadastro realizado\n\n");
                printf("\t\t\t\tDIGITE 1 PARA CONTINUAR E 0 PARA SAIR:  ");
                scanf("%d",&decisao);
                system("cls");
            }while(decisao);


        fornecedor=fopen("fornecedor.txt","wb");
        if(fornecedor==NULL){
            printf("arquivo nao pode ser aberto..");
       }
       else{
            for(i=0;i<cont;i++){
                cadastro=cadastro1[i];
                fwrite(&cadastro,sizeof(FORNECEDOR),1,fornecedor);
            }
        fclose(fornecedor);
        system("cls");
        }
    }
}







listar_fornecedor(){
    FILE *fornecedor;
    FORNECEDOR cadastro;
    FORNECEDOR aux;
    FORNECEDOR cadastro1[TAM];
    int cont=0,i=0;
        cabecalho();

    fornecedor=fopen("fornecedor.txt","rb");
    if(fornecedor == NULL){
        printf("\n\n\t\t\tAinda nao possui cadastros...\n\n");
    }
    else{
         while(fread(&cadastro,sizeof(FORNECEDOR),1,fornecedor)==1){
            cadastro1[i]=cadastro;
            cont++;
            i++;
         }
        fclose(fornecedor);

         int decisao=0,j;
         printf("SELECIONE UM MODO DE VISUALIZACAO: \n");
         printf("\t\t 1 PARA EXIBIR ITENS POR ANO:  \n");
         printf("\t\t 2 PARA EXIBIR ITENS POR NOME:  \n");
         scanf("%d",&decisao);
         system("cls");
             cabecalho();
         if(decisao==1){
            for(i=0;i<cont-1;i++){
                for(j=i+1;j<cont;j++){
                    if(cadastro1[i].ano>cadastro1[j].ano){
                            aux=cadastro1[i];
                            cadastro1[i]=cadastro1[j];
                            cadastro1[j]=aux;
                    }
                }
            }
         }
         else {
            for(i=0;i<cont-1;i++){
                for(j=i+1;j<cont;j++){
                    if(strcmp(cadastro1[i].nome,cadastro1[j].nome)==1){
                            aux=cadastro1[i];
                            cadastro1[i]=cadastro1[j];
                            cadastro1[j]=aux;
                    }
                }
            }
        }

             for(j=0;j<cont;j++){
                 if(decisao==1)
                   printf("\t\t\t\tANO %d\n\n",cadastro1[j].ano);

                else{
                    printf("\t\t\t\tORDEM ALFABETICA:\n\n\n");
                }
                    printf("CNPJ : %s\n",cadastro1[j].cnpj);
                    printf("NOME : %s\n",cadastro1[j].nome);
                    printf("CAPITAL SOCIAL : %f\n",cadastro1[j].capital_social);
                    printf("NOME REPRESENTANTE : %s\n",cadastro1[j].nome_representante);
                    printf("TELEFONE : %s\n",cadastro1[j].telefone);
                    printf("ANO : %d\n",cadastro1[j].ano);
                    printf("SITUACAO : %c\n",cadastro1[j].situacao);
                    printf("COD AREA : %d\n",cadastro1[j].cod_area);
                    printf("\n*******************************************************************************\n\n\n\n");
            }




        printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&cont);
        system("cls");

    }
}






printar_fornecedor(FORNECEDOR cadastro){
            printf("CNPJ : %s\n",cadastro.cnpj);
            printf("NOME : %s\n",cadastro.nome);
            printf("CAPITAL SOCIAL : %f\n",cadastro.capital_social);
            printf("NOME REPRESENTANTE : %s\n",cadastro.nome_representante);
            printf("TELEFONE : %s\n",cadastro.telefone);
            printf("ANO : %d\n",cadastro.ano);
            printf("SITUACAO : %c\n",cadastro.situacao);
            printf("COD AREA : %d\n",cadastro.cod_area);
}









incluir_area(){
        AREA cadastro;
        AREA cadastro1[TAM];
        FILE  *area;
        int decisao=1,i=0,cont=0,j;

            area=fopen("area.txt","rb");
            if(area==NULL){
                 do{
                    printf("\t\t\t\tCADASTRO AREA\n");
                    printf(" ******************************************************************************* \n");
                    printf("DIGITE O CODIGO : ");
                    scanf("%d",&cadastro1[i].codigo);
                    if(i!=0){
                        for(j=0;j<i;j++){

                            while(cadastro1[i].codigo == cadastro1[j].codigo){

                                printf("INVALIDO \n\n\n\t\t\tCODIGO JA EXISTENTE!!\n\n\n\n");
                                printf("DIGITE UM NOVO CODIGO : ");
                                scanf("%d",&cadastro1[i].codigo);
                                 system("cls");
                            }
                        }
                    }

                    printf("\n");
                    getchar();
                    printf("NOME : ");
                    scanf(" %[^\n]",cadastro1[i].nome);
                    getchar();
                    i++;
                    cont++;
                    printf("\n\n\t\t Cadastro realizado...\n");
                    printf("\n\n\t\t\t\t\tDIGITE 1 PARA CONTINUAR 0 PARA SAIR: ");
                    scanf("%d",&decisao);
                    system("cls");
                }while(decisao!=0);
                       area=fopen("area.txt","ab");
                if(area==NULL){
                    printf("arquivo nao pode ser aberto...");
                    exit(0);

                }

                else{
                        for(i=0;i<cont;i++){
                            cadastro=cadastro1[i];
                            fwrite(&cadastro,sizeof(AREA),1,area);
                        }

                    system("cls");
                    fclose(area);
                }

        }






            else{
                  while(fread(&cadastro,sizeof(AREA),1,area)==1){
                        cadastro1[i]=cadastro;
                        i++;
                        cont++;

                }
                 fclose(area);
                do{
                    printf("\t\t\t\tCADASTRO AREA\n");
                    printf(" ******************************************************************************* \n");
                    printf("DIGITE O CODIGO : ");
                    scanf("%d",&cadastro1[i].codigo);
                    if(i!=0){
                        for(j=0;j<i;j++){

                            while(cadastro1[i].codigo == cadastro1[j].codigo){

                                printf("INVALIDO \n\n\n\t\t\tCODIGO JA EXISTENTE!!\n\n\n\n");
                                printf("DIGITE UM NOVO CODIGO : ");
                                scanf("%d",&cadastro1[i].codigo);
                                 system("cls");
                            }
                        }
                    }

                    printf("\n");
                    getchar();
                    printf("NOME : ");
                    scanf(" %[^\n]",cadastro1[i].nome);
                    getchar();
                    i++;
                    cont++;
                    printf("\n\n\t\t Cadastro realizado...\n");
                    printf("\n\n\t\t\t\t\tDIGITE 1 PARA CONTINUAR 0 PARA SAIR: ");
                    scanf("%d",&decisao);
                    system("cls");
               }while(decisao!=0);



            area=fopen("area.txt","wb");
            if(area==NULL){
                printf("arquivo nao pode ser aberto...");
                exit(0);

            }

            else{
                    for(i=0;i<cont;i++){
                        cadastro=cadastro1[i];
                        fwrite(&cadastro,sizeof(AREA),1,area);
                    }

                system("cls");
                fclose(area);
            }
        }
}








consultar_area(){
    int decisao;
    do {
            printf("\t\t\t\tCADASTRO AREA\n");
           printf(" ********************************************************************************** \n");
        printf("\n 0 PARA VOLTAR MENU ANTERIOR: \n");
        printf("\n 1 PARA CONSULTA POR CODIGO: \n");
        printf("\n 2 PARA CONSULTA POR NOME: \n");
        fscanf(stdin,"%d",&decisao);
        system("cls");
        switch(decisao){
        case 0:
            decisao=0;
            break;
        case 1:
            consulta_codigo();
        break;
        case 2:
            consulta_nome_area();
        break;
        default:
            printf("\nOPCAO INVALIDA\n\n");
        }
    }while(decisao!=0);

}
 consulta_codigo(){
    int codigo;
    FILE *area;
    AREA cadastro;
    int cont=0;

    printf("\t\t\t\tCADASTRO AREA\n");
    printf(" ********************************************************************** \n");
    printf("DIGITE O CODIGO  PARA A CONSULTA: ");
    scanf("%d",&codigo);

    area=fopen("area.txt","rb");
    if(area==NULL){
        printf("\n\n\t\tAinda nao possui cadastros...\n");

    }
    else{
        while(fread(&cadastro,sizeof(AREA),1,area)==1){
            if (codigo == cadastro.codigo){
                cont++;
                printf("CODIGO: %d\n",cadastro.codigo);
                printf("NOME: %s\n",cadastro.nome);
                printf("\n*********************************************************************\n");
            }
        }
        if(cont==0){
            printf("\t\t\t\t\t\n\nCadastro nao Localizado...");
        }
        else{
            printf("\t\t\t%d Cadastro(s) Localizado(s)...\n\n",cont);
        }
        fclose(area);
        printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&cont);
        system("cls");
    }
 }



  consulta_nome_area(){
  char nome[50];
  int cont=0;

    FILE *area;
    AREA cadastro;

    printf("\t\t\t\tCADASTRO AREA\n");
    printf(" **************************************************************************** \n");
    printf("DIGITE O NOME PARA A CONSULTA: ");
    scanf(" %[^\n]s",nome);

    area=fopen("area.txt","rb");
    if(area==NULL){
        printf("\n\n\t\tAinda nao possui cadastros...");


    }
    else{
            while(fread(&cadastro,sizeof(AREA),1,area)== 1){
                if (strcmp(nome,cadastro.nome)==0){
                        printf("CODIGO: %d\n",cadastro.codigo);
                        printf("NOME: %s\n",cadastro.nome);
                        printf("\n****************************************************************************\n");
                        cont++;
                }
            }
            if(cont==0){
                printf("\t\t\t\n\nCadastro nao localizado...\n\n");
            }
            else{
                printf("\n\n\t\t%d Cadastro(s) localizado(s)\n\n",cont);
            }
             printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
            scanf("%d",&cont);
            fclose(area);
            system("cls");
    }


}









listar_area(){
      AREA cadastro;
      AREA cadastro1[TAM];
      AREA aux;
      FILE  *area;
      int cont=0,i=0,j=0;


            area=fopen("area.txt","rb");
            if(area==NULL){
                    printf("\n\n\t\tAinda nao possui cadastros...");


            }
            else{
                while(fread(&cadastro,sizeof(AREA),1,area)==1){
                        cadastro1[i]=cadastro;
                        i++;
                        cont++;

                }
            }
                 fclose(area);
         int decisao;

         printf("\t\t1 PARA EXIBIR ITENS POR CODIGO:  \n");
         printf("\t\t2 PARA EXIBIR ITENS POR NOME:  \n");
         scanf("%d",&decisao);
         system("cls");

         if(decisao==1){
            for(i=0;i<cont-1;i++){
                for(j=i+1;j<cont;j++){
                    if(cadastro1[i].codigo > cadastro1[j].codigo){
                            aux=cadastro1[i];
                            cadastro1[i]=cadastro1[j];
                            cadastro1[j]=aux;
                    }
                }
            }
         }
         else{
            for(i=0;i<cont-1;i++){
                for(j=i+1;j<cont;j++){
                    if(strcmp(cadastro1[i].nome,cadastro1[j].nome)==1){
                            aux=cadastro1[i];
                            cadastro1[i]=cadastro1[j];
                            cadastro1[j]=aux;
                    }
                }
            }
        }
          for(j=0;j<cont;j++){
                if(decisao==1){
                    printf("\t\t\tCODIGO %d\n\n",cadastro1[j].codigo);
                }
                else{
                    printf("\t\t\tORDEM ALFABETICA\n\n");
                }
                printf("CODIGO: %d\n",cadastro1[j].codigo);
                printf("NOME: %s\n",cadastro1[j].nome);
                printf("\n****************************************************************************\n\n\n\n\n");
         }

            printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
            scanf("%d",&cont);
            system("cls");
           // fclose(area);
            }






    consultar_fornecedor(){
    int decisao=0;


    do{
        cabecalho();
        printf("0 PARA VOLTAR\n");
        printf("1 PARA CONSULTA PELO CNPJ\n");
        printf("2 PARA CONSULTA PELO NOME DO FORNECEDOR\n");
        scanf("%d",&decisao);
        system("cls");
        switch(decisao){
            case 0:
                decisao=0;
            break;
            case 1:
                consulta_cnpj();
            break;
            case 2:
                consulta_nome();
            break;
            default:
                printf("OPCAO INVALIDA\n\n");
        }
    }while(decisao);
 }






   consulta_cnpj(){
       char cnpj[20];
        int cont=0;
        FILE *fornecedor;
        FORNECEDOR cadastro;
        getchar();
               cabecalho();

        printf("DIGITE O CNPJ: ");
        scanf(" %[0-9]s",cnpj);
        printf("\n\n");
        getchar();

        fornecedor= fopen("fornecedor.txt","rb");
        if(fornecedor==NULL){
              printf("\n\n\t\tAinda nao possui cadastros...");
        }
        else{
            while( fread(&cadastro,sizeof(FORNECEDOR),1,fornecedor)==1 ){
                if(strcmp(cadastro.cnpj,cnpj)==0){
                    printar_fornecedor(cadastro);
                    printf("\n\n***************************************************************\n\n");
                    cont++;
                }

            }
            if(cont==0){
                printf("\n\n\t\t\tCadastro nao localizado....");
            }
            else{
                printf("%d Cadastro(s) Localizado(s)...",cont);
            }

             printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
            scanf("%d",&cont);
            fclose(fornecedor);
            system("cls");
        }
   }





    consulta_nome(){
        char *nome;
        nome=(char*)malloc(sizeof(char)*50);
          int cont=0;
        FILE *fornecedor;
        FORNECEDOR cadastro;
       cabecalho();
        getchar();
        printf("DIGITE O NOME DO REPRESENTANTE: ");
        scanf("%[^\n]s",nome);
        printf("\n\n\n\n\n");

        fornecedor = fopen("fornecedor.txt","rb");

        if(fornecedor==NULL){
                printf("\n\n\t\tAinda nao possui cadastros...");
        }
        else{
            while( fread(&cadastro,sizeof(FORNECEDOR),1,fornecedor)==1){
                if(strcmp(nome,cadastro.nome)==0){
                    printar_fornecedor(cadastro);
                    cont++;
                    printf("\n\n\n\n*****************************************************************************\n\n\n\n");
                }
            }
             if(cont==0){
                printf("\n\n\t\t\tCadastro nao localizado....");
            }
            else{
                printf("%d Cadastro(s) Localizado(s)...",cont);
            }
            }


           printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
            scanf("%d",&cont);
            fclose(fornecedor);
            system("cls");
        }







void excluir_fornecedor(){
    FILE *fornecedor;
    FORNECEDOR cadastro[TAM];
    FORNECEDOR cadastro1;
    cabecalho();
    int cont1=0;

    int i=0,cont=0;
    char cnpj[20];
    int decisao=0;
    printf("DIGITE O CNPJ A SER EXCLUIDO: ");
    scanf(" %[0-9]",cnpj);
    fornecedor=fopen("fornecedor.txt","rb+");
        if (fornecedor==NULL){
             printf("\n\n\t\tAinda nao possui cadastros...");

        }
        else{
            while(fread(&cadastro1,sizeof(FORNECEDOR),1,fornecedor)== 1){
                cadastro[i]=cadastro1;
                i++;
                cont++;
            }

            fclose(fornecedor);
            fornecedor=fopen("fornecedor.txt","wb");
            if(fornecedor==NULL){
                printf("\n\n\t\tAinda nao possui cadastros...");
            }
            else{

            for(i=0;i<cont;i++){
                if (strcmp(cnpj,cadastro[i].cnpj)== 0){
                    printf("\n\n\t\t\tArquivo apagado...\n");
                    cont1=1;
                }

                else{
                    fwrite(cadastro+i,sizeof(FORNECEDOR),1,fornecedor);
                }
            }
            fclose(fornecedor);
            }

        }

            if(cont==0){
               printf("\n\n\n\n\t\t\tCadastro nao localizado....");
            }

         printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&decisao);
        system("cls");
    }
    excluir_area(){
     FILE *area;
    AREA cadastro[TAM];
    AREA cadastro1;


    int i=0,cont=0,cont1=0;
    int codigo;
    int decisao=0;
    printf("DIGITE O CODIGO DA AREA  A SER EXCLUIDO: ");
    scanf("%d",&codigo);
    area=fopen("area.txt","rb");
        if (area==NULL){
           printf("\n\n\t\tAinda nao possui cadastros...");

        }
        else{
            while(fread(&cadastro1,sizeof(AREA),1,area)== 1){
                cadastro[i]=cadastro1;
                i++;
                cont++;
            }

            fclose(area);
            area=fopen("area.txt","wb");
            if(area == NULL){
               printf("\n\n\t\tAinda nao possui cadastros...");
            }
            else{

            for(i=0;i<cont;i++){
                if (codigo == cadastro[i].codigo){
                    printf("Arquivo apagado...\n");
                    cont1=1;
                }

                else{
                    fwrite(cadastro+i,sizeof(AREA),1,area);
                }
            }
            fclose(area);
            }

        }

        if(cont1==0){
               printf("\n\n\n\n\t\t\tCadastro nao localizado....");
            }
        printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&decisao);
        system("cls");
        }





        cabecalho(){
            printf("\t\t\t\tCADASTRO FORNECEDOR\n\n");
            printf("*****************************************************************************\n");
        }









        void alterar_fornecedor(){
                 FILE *fornecedor;
    FORNECEDOR cadastro[TAM];
    FORNECEDOR cadastro1;
    cabecalho();

    int i=0,cont=0;
    char cnpj[20];
    int decisao=0;
    printf("DIGITE O CNPJ A ALTERADO: ");
    scanf(" %[0-9]",cnpj);
    fornecedor=fopen("fornecedor.txt","rb+");
        if (fornecedor==NULL){
             printf("\n\n\t\tAinda nao possui cadastros...");

        }
        else{
            while(fread(&cadastro1,sizeof(FORNECEDOR),1,fornecedor)== 1){
                cadastro[i]=cadastro1;
                i++;
                cont++;
            }

            fclose(fornecedor);
            fornecedor=fopen("fornecedor.txt","wb");
            if(fornecedor==NULL){
                printf("\n\n\t\tAinda nao possui cadastros...");
            }
            else{
            int controle;
            for(i=0;i<cont;i++){
                if (strcmp(cnpj,cadastro[i].cnpj)== 0){
                        printf("\t\t\tCADASTRO ATUAL\n\n\n");
                        printar_fornecedor(cadastro[i]);
                        printf("\n\n");
                        printf("\t\t\t\t\nESCOLHA 1 ITEM PARA FAZER A ALTERACAO: \n\n\n\n");
                        printf("\t\t1 CNPJ : \n");
                        printf("\t\t2 NOME : \n");
                        printf("\t\t3 CAPITAL SOCIAL \n");
                        printf("\t\t4 NOME REPRESENTANTE \n");
                        printf("\t\t5 TELEFONE : \n");
                        printf("\t\t6 ANO : \n");
                        printf("\t\t7 SITUACAO :\n");
                        printf("\t\t8 COD AREA : \n");
                        printf("ESCOLHA UMA OPCAO: ");
                        scanf("%d",&controle);
                        system("cls");
                        switch(controle){
                            case 1:
                                getchar();
                                printf("DIGITE O CNPJ: ");
                                scanf(" %[0-9]",cadastro[i].cnpj);
                                printf("\n");
                               getchar();
                               break;
                           case 2:
                                getchar();
                                printf("DIGITE O NOME DO FORNECEDOR : ");
                                scanf("%[^\n]s",cadastro[i].nome);
                                printf("\n");
                                getchar();
                                break;
                            case 3:

                                printf("DIGITE O CAPITAL SOCIAL : ");
                                scanf("%f",&cadastro[i].capital_social);
                                 printf("\n");
                                getchar();
                                break;
                            case 4:
                                getchar();
                                printf("DIGITE O NOME DO REPRESENTANTE: ");
                                scanf("%[^\n]",cadastro[i].nome_representante);
                                 printf("\n");
                                getchar();
                                break;
                            case 5:
                                getchar();
                                printf("DIGITE O TELEFONE: ");
                                scanf("%s",cadastro[i].telefone);
                                 printf("\n");
                                getchar();
                            case 6:
                                printf("DIGITE O ANO : ");
                                scanf("%d",&cadastro[i].ano);
                                printf("\n");
                                getchar();
                                break;
                            case 7:
                                getchar();
                                printf("DIGITE A SITUACAO  (A) PARA ATIVO  E (I) PARA INATIVO: ");
                                scanf("%c",&cadastro[i].situacao);
                                 printf("\n");
                                getchar();
                                break;
                            case 8:
                                printf("DIGITE O CODIGO DA AREA : ");
                                scanf("%d",&cadastro[i].cod_area);
                                 printf("\n");
                                 break;
                            default:
                                printf("OPCAO INVALIDA!");
                            }
                             printf("\n\n\t\t Alteracao Concluida\n\n");
                              fwrite(cadastro+i,sizeof(FORNECEDOR),1,fornecedor);



                                }

                else{
                    fwrite(cadastro+i,sizeof(FORNECEDOR),1,fornecedor);
                }
            }
            fclose(fornecedor);
            }

        }
         printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&decisao);
        system("cls");
    }
    alterar_area(){
    FILE *area;
    AREA cadastro[TAM];
    AREA cadastro1;


    int i=0,cont=0;
    int codigo;
    int decisao=0;
    printf("DIGITE O CODIGO DA AREA  A SER ALTERADO: ");
    scanf("%d",&codigo);
    area=fopen("area.txt","rb");
        if (area==NULL){
           printf("\n\n\t\tAinda nao possui cadastros...");

        }
        else{
            while(fread(&cadastro1,sizeof(AREA),1,area)== 1){
                cadastro[i]=cadastro1;
                i++;
                cont++;
            }

            fclose(area);
            area=fopen("area.txt","wb");
            if(area == NULL){
                  printf("\n\n\t\tAinda nao possui cadastros...");
            }
            else{
            int controle;
            for(i=0;i<cont;i++){
                if (codigo == cadastro[i].codigo){
                    printf("\t\t\tCADASTRO  ATUAL\n\n");
                    printf("CODIGO: %d\n",cadastro[i].codigo);
                    printf("NOME: %s\n",cadastro[i].nome);

                    printf("ESCOLHA 1 DADO PARA SER ALTERADO: \n");
                    printf("\t\t 1 CODIGO: \n");
                    printf("\t\t 2 NOME : \n");
                    scanf("%d",&controle);
                    switch(controle){
                        case 1 :

                            printf("CODIGO: ");
                            scanf("%d",&cadastro[i].codigo);
                            break;
                        case 2:
                            getchar();
                            printf("NOME: ");
                            scanf("%[^\n]",cadastro[i].nome);
                            getchar();
                            break;
                        default:
                            printf("OPCAO INVALILDA! \n");
                        }
                        printf("\n\n\t\t Alteracao Concluida\n\n");
                        fwrite(cadastro+i,sizeof(AREA),1,area);

                    }


                else{
                    fwrite(cadastro+i,sizeof(AREA),1,area);
                }
            }
            fclose(area);
            }

        }
        printf("\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&decisao);
        system("cls");
    }
listar_fornecedor_area(){

    FORNECEDOR cadastro;
     FORNECEDOR cadastro1[TAM];
    FILE *fornecedor;
    FILE *area;
    AREA cadastro_area;
    AREA cadastro_area1[TAM];
    int i=0,j=0,cont=0,cont1=0,cont2=0;
    fornecedor=fopen("fornecedor.txt","rb");
         if (fornecedor==NULL){
                printf("\n\n\t\tAinda nao possui cadastros...");
        }
        else{
            while(fread(&cadastro,sizeof(FORNECEDOR),1,fornecedor)== 1){

                cadastro1[j]=cadastro;
                j++;
                cont1++;
            }
           // printf("cont==1");
            fclose(fornecedor);

            area=fopen("area.txt","rb");
            if(area==NULL){
                printf("\n\n\t\tAinda nao possui cadastros...");
            }
            else{
                while(fread(&cadastro_area,sizeof(AREA),1,area)==1){
                    cadastro_area1[i]=cadastro_area;
                    i++;
                    cont++;
                }
                fclose(area);

            }

            for(j=0;j<cont1;j++){
                    for(i=0;i<cont;i++){
                            if(cadastro1[j].cod_area == cadastro_area1[i].codigo){
                                printf("\t\t\tCODIGO: %d \n",cadastro_area1[i].codigo);
                                printf("\t\t\tAREA:   %s\n\n",cadastro_area1[i].nome);
                                printf("CNPJ : %s\n",cadastro1[j].cnpj);
                                printf("NOME : %s\n",cadastro1[j].nome);
                                printf("CAPITAL SOCIAL : %f\n",cadastro1[j].capital_social);
                                printf("NOME REPRESENTANTE : %s\n",cadastro1[j].nome_representante);
                                printf("TELEFONE : %s\n",cadastro1[j].telefone);
                                printf("ANO : %d\n",cadastro1[j].ano);
                                printf("SITUACAO : %c\n",cadastro1[j].situacao);
                                printf("COD AREA : %d\n",cadastro1[j].cod_area);
                                printf("\n*******************************************************************************\n");

                                cont2=1;
                            }
                    }
            }



        }
        int decisao=0;
        if(cont2==0)
            printf("\n\n\n\n\n\t\tCadastro nao localizado....");


        printf("\n\n\n\n\n\n\n\n\t\t\t 0 Para voltar ao menu  anterior : ");
        scanf("%d",&decisao);
        system("cls");
}






