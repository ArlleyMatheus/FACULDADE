#include <stdio.h>
int main (){
 int m[6][6];
 int i=0, l,c,e=0,f=0;
 int s1=0,s2=0,s3=0,s4=0,s5=0,s6=0,a=0,b=0,d=0;
  int s =0;
    for (l=0;l<6;l++){
        for (c=0;c<6;c++){
            //printf("digite o numero para a %d linha da %d coluna ",l+1,c+1);
            scanf("%d",&m[l][c]);
    }}
           for (l=0;l<1;l++){
              for (c=0;c<3;c++){    s =m[l][c]+s;


                ;}}a=s;//printf("%d\n",a);
                   for (l=2;l<3;l++){
                             for (c=0;c<3;c++){    s2 =m[l][c]+s2;}}b=s2;
                            // printf("%d\n",b);

                       for (l=3;l<4;l++){
                            for (c=3;c<6;c++){    s3 =m[l][c]+s3;}}i=s3;//printf("%d\n",i);

                                       for (l=5;l<6;l++){
                                          for (c=3;c<6;c++){
                    s4 =m[l][c]+s4;




       }}
       d=s4;//printf("%d\n",d);

                                               for (l=1;l<2;l++){
                                             for (c=1;c<2;c++){
                                                    s5=s5+m[l][c];}}
                                             e=s5 ;
                                           //  printf("%d\n",e);
                                                    for (l=4;l<5;l++){
                                                      for (c=4;c<5;c++){s6=s6+m[l][c];
                                                      }}
                                                      f=s6;
                                                     // printf("%d\n",f);




       ; //printf("%d\n",a+b+i+d+e+f);

       if ((a+b+e)>(i+f+d)){

             printf("%d",a+d+e);}
       else{
       printf("%d",i+f+d);
       }
    }








