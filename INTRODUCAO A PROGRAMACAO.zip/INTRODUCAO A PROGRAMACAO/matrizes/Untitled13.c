#include<stfio.h>
int main (){
  int m[2][2],m1[]
  int l,c;
       for (l=0;l<2;l++){
        for (c=0;c<2;c++){

            scanf("%d",&m[l][c]);

        }
       }
                   for (l=0;l<2;l++){
                          for (c=0;c<1;c++){



}
