#include<stdio.h>
int main (){
    int n,l,c;
   // printf("digite o tamanho da matrix : ");
    scanf("%d",&n);
    int m[n][n];
    int m1[n][n];
    int diagonal=0;
    for(l=0;l<n;l++){
        for(c=0;c<n;c++){
            scanf("%d",&m[l][c]);

            }
        }


    for(l=0;l<n;l++){
        for(c=0;c<n;c++){
            m1[c][l]=m[l][c];
            if(l==c){
                diagonal+=m[l][c];
            }
        }
    }
    for(l=0;l<n;l++){
        for(c=0;c<n;c++){
                m[l][c]*=diagonal;
        }
    }
    for(l=0;l<n;l++){
        for(c=0;c<n;c++){
            m[l][c]+= m1[l][c];
        }
    }
    for(l=0;l<n;l++){
        for(c=0;c<n;c++){
                printf("%d ",m[l][c]);
        }
    printf("\n");
    }
}



