#include<stdio.h>
int main(){
    int l,c,i,j;
   // printf("digite o tamanho das linhas e colunas da matriz ");
    scanf("%d %d",&l,&c);
    int wally[l][c];
    for(i=0;i<l;i++){
        for(j=0;j<c;j++){
            scanf("%d",&wally[i][j]);
        }
    }
    int cont=0;
    for(i=0;i<l;i++){
        for(j=0;j<c;j++){
            if (wally[i][j] == 1111){
              if ((wally[i][j-1] == 0) || (wally[i][c-1] == 0)) {
                    if ((wally[i][j+1] == 0) || (wally[i][0] == 0)) {
                        if ((wally[i-1][j] == 4) || (wally[l-1][j] == 4)) {
                            if ((wally[i+1][j] == 8) || (wally[0][j] == 8)) {
                                cont++;
                                printf("%d %d\n", i, j);
                            }
                        }
                    }
                }
            }
        }
    }
      if (cont == 0) {
    printf("WALLY NAO ESTA NA MATRIZ\n");
  }
    return 0;
}




