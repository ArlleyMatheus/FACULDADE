#include<stdio.h>
int main(){
    int l, c;
    float matriz[2][2], resultado[2][2];

    for(l= 0; l < 2; l++){
        for(c = 0; c < 2; c++){
            scanf("%f", &matriz[l][c]);
            getchar();
        }
    }
            resultado[0][0] = (matriz[0][0]*matriz[0][0]) + (matriz[0][1]*matriz[1][0]);
            resultado[0][1] = (matriz[0][0]*matriz[0][1]) + (matriz[0][1]*matriz[1][1]);
            resultado[1][0] = (matriz[1][0]*matriz[0][0]) + (matriz[1][1]*matriz[1][0]);
            resultado[1][1] = (matriz[1][0]*matriz[0][1]) + (matriz[1][1]*matriz[1][1]);

            for(l = 0; l < 2; l++){
                for(c = 0; c < 2; c++){
                    printf("%.3f ", resultado[l][c]);
                    //Imprimir espaço entre os elementos


                }
                printf("\n");
            }
    }


