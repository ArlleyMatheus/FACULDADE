#include<stdio.h>
int main() {

  int l, c, apostas, sena = 0, quina = 0, quadra = 0, sorteio[6];
  int i, contador;

  scanf("%d", &apostas);
  int jogo[apostas][6];

  for (l = 0; l < apostas; l++) {
    for (c = 0; c < 6; c++) {
      scanf("%d", &jogo[l][c]);
    }
  }

  for (i = 0; i < 6; i++) {
    scanf("%d", &sorteio[i]);
  }

  for (l = 0; l < apostas; l++) {
    for (c = 0, contador = 0; c < 6; c++) {
      for (i = 0; i < 6; i++) {
        if (jogo[l][c] == sorteio[i]) {
          contador++;
        }
      }
    }
     if (contador == 4) {
      quadra++;
    }
   if (contador == 5) {
      quina++;
    }

    if (contador == 6) {
      sena++;
    }
  }

  if (sena >= 1) {
    printf("Houve %d acertador(es) da sena\n", sena);
  }   else {
        printf("Nao houve acertador para sena\n");
      }

  if (quina >= 1) {
    printf("Houve %d acertador(es) da quina\n", quina);
  }   else {
        printf("Nao houve acertador para quina\n");
      }

  if (quadra >= 1) {
    printf("Houve %d acertador(es) da quadra\n", quadra);
  }   else {
        printf("Nao houve acertador para quadra\n");
      }
  return 0;
}
