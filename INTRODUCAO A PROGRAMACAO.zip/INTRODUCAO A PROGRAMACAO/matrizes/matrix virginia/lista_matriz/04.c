#include<stdio.h>
int main(){
            //04 Ler e imprimir
  int i, j, linha, coluna, contador=1;

  scanf("%d", &i);
  while(contador--){

    if (i > 0 && i < 11) {
      if (j > 0 && j < 11) {

        int matriz[i][j];

        for (linha = 0; linha < i; linha++) {
          for (coluna = 0; coluna < j; coluna++) {
            scanf("%d", &matriz[linha][coluna]);
          }
        }
        for (linha = 0; linha < i; linha++) {
          printf("linha %d: ", linha+1);
          for (coluna = 0; coluna < j; coluna++) {
            printf("%d", matriz[linha][coluna]);
            if (coluna < j-1) {
              printf(",");
            }
            if (coluna == j-1) {
              printf("\n");
            }
          }
        }
      }   else {
          contador++;
          scanf("%d", &j);
          }
    } else {
      contador++;
      scanf("%d", &i);
      }
  }
return 0;
}
