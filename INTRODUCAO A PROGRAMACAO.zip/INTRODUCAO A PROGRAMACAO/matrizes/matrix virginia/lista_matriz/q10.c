#include<stdio.h>
int main (){
	int i, j, tamanho, linha, coluna, diagonal, enter;

	scanf("%d", &tamanho);

	int matriz[tamanho][tamanho], transposta[tamanho][tamanho], resultado[tamanho][tamanho];

	for(linha = 0; linha < tamanho; linha++){
		for(coluna = 0; coluna < tamanho; coluna++){
			scanf("%d", &matriz[linha][coluna]);
			transposta[coluna][linha] = matriz[linha][coluna];
		}
	}

	for(linha = 0, coluna = 0, diagonal = 0; linha < tamanho; linha++, coluna++){
		diagonal += matriz[linha][coluna];
	}

	for(linha = 0; linha < tamanho; linha++){
		for(coluna = 0; coluna < tamanho; coluna++){
			matriz[linha][coluna] *= diagonal;
			resultado[linha][coluna] = matriz[linha][coluna] + transposta[linha][coluna];
		}
	}

	for(linha = 0, enter = 0; linha < tamanho; linha++){
		for(coluna = 0; coluna < tamanho; coluna++){
			printf("%d", resultado[linha][coluna]);
			enter++;
			if(enter == tamanho){
			printf("\n");
			enter = 0;
			}	else {
				printf(" ");
				}
		}
	}

return 0;
}
