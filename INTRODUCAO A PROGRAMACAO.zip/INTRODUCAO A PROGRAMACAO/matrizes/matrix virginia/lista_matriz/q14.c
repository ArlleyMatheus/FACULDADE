#include<stdio.h>
int main (){
  int i, j, l, c, maiorLinha = 0, maiorColuna = 0, menorLinha = 0, menorColuna = 0;
  double percentualMaior, percentualMenor, maior = 0, menor = 0;
  scanf("%d %d", &l, &c);
  int matriz[l][c];
  for (i = 0; i < l; i++) {
    for (j = 0; j < c; j++) {
      scanf("%d", &matriz[i][j]);
    if (matriz[i][j] > matriz[maiorLinha][maiorColuna]) {
        maiorLinha = i;
        maiorColuna = j;
    }
      if (matriz[i][j] < matriz[menorLinha][menorColuna]) {
        menorLinha = i;
        menorColuna = j;
      }
    }
  }
  for (i = 0; i < l; i++) {
    for (j = 0; j < c; j++) {
      if (matriz[i][j] == matriz[maiorLinha][maiorColuna]) {
        maior++;
      }
      if (matriz[i][j] == matriz[menorLinha][menorColuna]) {
        menor++;
      }
    }
  }
  percentualMaior = (double)(maior/(l*c))*100;
  percentualMenor = (double)(menor/(l*c))*100;
  printf("%d %.2lf%%\n", matriz[menorLinha][menorColuna], percentualMenor);
  printf("%d %.2lf%%\n", matriz[maiorLinha][maiorColuna], percentualMaior);
}
