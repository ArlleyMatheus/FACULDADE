#include<stdio.h>
int main(){
            //05 Matriz xadrez (+)
  int i, j, linha, coluna, chave = 1, enter;

  scanf("%d %d", &linha, &coluna);

  int matriz[linha][coluna];

	for (i = 0, enter = 0; i < linha; i++) {
		for (j = 0; j < coluna; j++) {
			if (enter == coluna){
				printf("\n");
				enter = 0;
				if (coluna % 2 == 0){
					if (chave){
					chave = 0;
					}	else {
							if (!chave){
							chave = 1;
							}
						}
				}
			}
			if (chave){
				printf("1");
				chave = 0;
				enter++;
    		} 	else {
					if (!chave){
					printf("0");
					chave = 1;
					enter++;
					}
				}
		}
	}
	printf("\n");
return 0;
}
