
    //Verificar presença do Logotipo no Vídeo



    for (linha = 0; linha < dimVideo; linha++) {
      for (coluna = 0; coluna < dimVideo; coluna++) {
        //Encontrar o primeiro elemento do Logotipo

        if (matrizLogo[0][0] == matrizVideo[linha][coluna]) {
          incrementoLinha = 0;
          incrementoColuna = 0;
          total = 0;
          //Verificar se o Logotipo está completo
          for (linha2 = linha    ,     i = 0;    i < dimLogotipo    ;         linha2++, i++) {

            for (coluna2 = coluna        , j = 0; j < dimLogotipo;           coluna2++, j++) {
              if (matrizLogo[incrementoLinha][incrementoColuna] == matrizVideo[linha2][coluna2]) {

                //Incrementar coluna + 1 de matrizLogo
                incrementoColuna++;
                //Contador geral para resultado
                total++;
                //printf("%d\n", total);
              }
            }
            //Verificar se contou até o fim da coluna
              incrementoColuna = 0;
              contador = 0;
              incrementoLinha++;
          }

        }
        if (total == dimLogotipo*dimLogotipo) {
          break;
        }
      }
      if (total == dimLogotipo*dimLogotipo) {
        break;
      }
    }
    if (total == (dimLogotipo*dimLogotipo)) {
      printf("sim\n");
    }   else {
          printf("nao\n");
        }
  return 0;
}
