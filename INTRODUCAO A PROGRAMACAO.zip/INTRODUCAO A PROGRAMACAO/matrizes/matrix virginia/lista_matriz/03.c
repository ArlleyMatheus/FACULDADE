#include<stdio.h>
int main(){
            //6 Diagonal Secundária
  int tamanho, linha, coluna;

  scanf("%d", &tamanho);

  int matriz[tamanho][tamanho];

  for (linha = 0; linha < tamanho; linha++) {
    for (coluna = 0; coluna < tamanho; coluna++) {
      scanf("%d", &matriz[linha][coluna]);
    }
  }
  for (linha = 0, coluna = tamanho-1; linha < tamanho; linha++, coluna--) {
    printf("%d\n", matriz[linha][coluna]);
  }
return 0;
}
