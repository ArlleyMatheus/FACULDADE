#include<stdio.h>
int main(){

  int i, maior, c, l, soma[36];
  int  matriz[6][6];

  for (l = 0; l < 6; l++) {
    for (c = 0; c < 6; c++) {
      scanf("%d", &matriz[l][c]);
    }
  }
  for (i = 0; i < 36; i++) {
    soma[i] = 0;
  }
    for (l = 0, i = 0; l < 4; l++) {
    for (c = 0; c < 4; c++){
      if (matriz[l][c] != 0) {
        soma[i] = matriz[l][c] + matriz[l][c+1] + matriz[l][c+2]
        + matriz[l+1][c+1] + matriz[l+2][c] + matriz[l+2][c+1] + matriz[l+2][c+2];
        i++;
      }
    }
  }

  for (l = 1, maior = 0; l < i; l++) {
    if (soma[l] > soma[maior]) {
      maior = l;
    }
  }
  printf("%d\n", soma[maior]);
return 0;
}
