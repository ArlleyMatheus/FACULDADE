#include<stdio.h>
int main (){
            //11 Cidade Segura
  int linha, coluna, quadrada, contador, seguro;

  scanf("%d", &quadrada);
  quadrada++;
  int matriz[quadrada][quadrada];

  for (linha = 0; linha < quadrada; linha++) {
    for (coluna = 0; coluna < quadrada; coluna++) {
      scanf("%d", &matriz[linha][coluna]);
    }
  }

  for (linha = 0; linha < quadrada-1; linha++) {
    for (coluna = 0; coluna < quadrada-1; coluna++) {
      if (matriz[linha][coluna] + matriz[linha+1][coluna]+matriz[linha][coluna+1]+matriz[linha+1][coluna+1] >= 2) {
        printf("S");
      } else {
        printf("U");
        }
    }
    printf("\n");
  }
return 0;
}
