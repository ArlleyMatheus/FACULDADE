#include <stdio.h>
int main() {
            //18 Valida Sudoku
  int linha, coluna, sudoku[9][9];
  int valida[9];
  int contador = 0, contador2 = 1, validar = 0, i;

  //Loop para gerar a matriz do Sudoku
  for (linha = 0; linha < 9; linha++) {
    //Reiniciar o vetor valida[9]
    for (i = 1; i <= 9; i++) {
      valida[i] = i;
    }
    for (coluna = 0; coluna < 9; coluna++) {
      //Ler os valores do Sudoku
      scanf("%d", &sudoku[linha][coluna]);
      getchar();
      //Percorrer o vetor valida[9]
      for (i = 0; i < 9; i++) {
        //Validar os elementos das linhas
        if (sudoku[linha][coluna] == valida[i]) {
          contador++;
          valida[i] = 0;
        }
      }
    }
    //printf("%d\n", contador);
  }
  //Verificar se todas as linhas são válidas
  if (contador == 72) {
    validar++;
  }
  for (coluna = 0; coluna < 9; coluna++) {
    //Reiniciar o vetor valida[9]
    for (i = 1; i <= 9; i++) {
      valida[i] = i;
    }
    for (linha = 0; linha < 9; linha++) {
      //Percorrer o vetor valida[9]
      for (i = 0; i < 9; i++) {
        //Validar os elementos das linhas
        if (sudoku[linha][coluna] == valida[i]) {
          contador2++;
          valida[i] = 0;
        }
      }
    }
    //printf("%d\n", contador2);

  }
  //Verificar se todas as colunas são válidas
  if (contador2 == 72) {
    validar++;
  }
  if (validar == 2) {
    printf("valido\n");
    //printf("Contador: %d\nContador2: %d\n", contador, contador2);
  } else {
      printf("invalido\n");
      //printf("Contador: %d\nContador2: %d\n", contador, contador2);
  }
  return 0;
}
