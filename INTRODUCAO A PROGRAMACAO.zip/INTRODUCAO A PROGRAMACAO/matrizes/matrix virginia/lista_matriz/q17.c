#include<stdio.h>
int main() {

  int tam, i, j, k, linhaM;
  scanf("%d", &tam);
  int matriz[tam][tam], aux=0;

  for (i = 0; i < tam; i++) {
    for (j = 0; j < tam; j++) {
      scanf("%d", &matriz[i][j]);
    }
  }

  for (i = 0; i < tam; i++) {
    for (j = 0; j < tam; j++) {
      linhaM=j;
      for (k = j+1; k < tam; k++) {
        if (matriz[k][i] < matriz[linhaM][i]) {
          linhaM=k;
        }
      }
      aux=matriz[j][i];
      matriz[j][i]=matriz[linhaM][i];
      matriz[linhaM][i]=aux;
    }
  }

for (i = 0; i < tam; i++) {
  for (j = 0; j < tam; j++) {
    printf("%d", matriz[i][j]);
    if (j<tam-1) {
      printf(" ");
    } else {
      printf("\n");
      }
  }
}

}
