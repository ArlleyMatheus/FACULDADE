#include<stdio.h>
int main(){
            //01 Determinante 2x2
  int linha, coluna;
  float determinante=0, matriz[2][2];

  for (linha = 0; linha < 2; linha++) {
    for (coluna = 0; coluna < 2; coluna++) {
      scanf("%f", &matriz[linha][coluna]);
    }
  }
  determinante = (matriz[0][0]*matriz[1][1]) - (matriz[0][1]*matriz[1][0]);

  printf("%.2f\n", determinante);
return 0;
}
