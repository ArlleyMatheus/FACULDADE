#include<stdio.h>
int main (){
    //17 Troca Maior Menor
    int linha, coluna, i, j, maiorLinha = 0, maiorColuna = 0, menorColuna = 0, menorLinha = 0, auxLinha = 0, auxColuna = 0;

    scanf("%d %d", &linha, &coluna);
    int matriz[linha][coluna], matrizAux[linha][coluna];

    for(i = 0; i < linha; i ++){
        for(j = 0; j < coluna; j++){
            //Ler e armazenar matriz
            scanf("%d", &matriz[i][j]);
            //Encontrar maior elemento
            if(matriz[i][j] > matriz[maiorLinha][maiorColuna]){
                maiorColuna = j;
                maiorLinha = i;
            }
            //Encontrar menor elemento
            if(matriz[i][j] < matriz[menorLinha][menorColuna]){
                menorColuna = j;
                menorLinha = i;
            }
        }
    }

    //printf("Menor: %d\nMaior: %d\n", matriz[menorLinha][menorColuna], matriz[maiorLinha][maiorColuna]);

    //Realizar trocas de elementos
    matrizAux[auxLinha][auxColuna] = matriz[menorLinha][menorColuna];
    matriz[menorLinha][menorColuna] = matriz[maiorLinha][maiorColuna];
    matriz[maiorLinha][maiorColuna] = matrizAux[auxLinha][auxColuna];

    for(i = 0; i < linha; i++){
        for(j = 0; j < coluna; j++){
            //Imprimir elementos da matriz
            printf("%d", matriz[i][j]);
            //Imprimir espa�o entre os elementos
            if(j < coluna-1){
                printf(" ");
            }
            //Imprimir quebra de linha
            if(j == coluna-1){
                printf("\n");
            }
        }
    }

return 0;
}
