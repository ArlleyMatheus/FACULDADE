#include<stdio.h>
int main(){
            //10 Cadê o Wally?
  int i, j, contador, linha, coluna;

  scanf("%d %d", &linha, &coluna);
  int wally[linha][coluna];

  for (i = 0; i < linha; i++) {
    for (j = 0; j < coluna; j++) {
      scanf("%d", &wally[i][j]);
    }
  }
  for (i = 0, contador = 0; i < linha; i++) {
    for (j = 0; j < coluna; j++) {
      if (wally[i][j] == 1111){
        //printf("1\n");
        if ((wally[i][j-1] == 0) || (wally[i][coluna-1] == 0)) {
          //printf("2\n");
          if ((wally[i][j+1] == 0) || (wally[i][0] == 0)) {
            //printf("3\n");
            if ((wally[i-1][j] == 4) || (wally[linha-1][j] == 4)) {
              //printf("4\n");
              if ((wally[i+1][j] == 8) || (wally[0][j] == 8)) {
                contador++;
                printf("%d %d\n", i, j);
              }
            }
          }
        }
      }
    }
  }
  if (contador == 0) {
    printf("WALLY NAO ESTA NA MATRIZ\n");
  }
return 0;
}
