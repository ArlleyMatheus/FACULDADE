#include<stdio.h>
int main(){
            //08 Matriz xadrez numerada (++)
  int i, j, linha, coluna, chave = 0, enter, numero;

  scanf("%d %d", &linha, &coluna);

  int matriz[linha][coluna];

	for (i = 0, enter = 0, numero = 1; i < linha; i++) {
		for (j = 0; j < coluna; j++) {
			if (enter == coluna){
				printf("\n");
				enter = 0;
				if (coluna % 2 == 0){
					if (chave){
					chave = 0;
					}	else {
							if (!chave){
							chave = 1;
							}
						}
				}
			}
			if (chave){
				printf("%d", numero);
				numero++;
				chave = 0;
				enter++;
    		} 	else {
					if (!chave){
					printf("0");
					chave = 1;
					enter++;
					}
				}
		if(j < coluna-1){
		printf(" ");
		}
		}
	}
	printf("\n");
return 0;
}
