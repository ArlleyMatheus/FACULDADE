#include<stdio.h>
int main(){
    int matrix[6][6];
    int l,c,maior=0,soma=0,i=0;
    for(l=0;l<6;l++){
        for(c=0;c<6;c++){
          //  printf("digite os numeros: ");
            matrix[l][c]= i;
            i++;

        }
    }
    i=0;
    int j=0;
    for(l=0;l<6;l++){
        for(c=0;c<6;c++){
            printf("%7d",matrix[l][c]);
        }
        printf("\n");
    }
     for(l=0;l<6;l++){
        for(c=0;c<6;c++){
            if(i!=3&& l<=3){
                soma+=matrix[l][c];
                i++;
            }
            else{
                c=0;
                l+=1;
                soma+=matrix[l][c+1];
            }
            if(i!=3 && l<=3){
                soma+=matrix[l+2][c];
            }
        }
     }
     printf("%d",soma);
}


