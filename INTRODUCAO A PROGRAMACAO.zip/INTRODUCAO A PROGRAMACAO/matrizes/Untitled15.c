#include<stdio.h>
int main (){
    int n,i,j,l,c;
   // printf("digite o tamanho da 1 matrix");
    scanf("%d",&l);
    int m[l][l];
    for(i=0;i<l;i++){
        for(j=0;j<l;j++){
            scanf("%d",&m[i][j]);
        }
    }
    //printf("digite o tamanho da segunda matriz ");
    scanf("%d",&n);
    int m1[n][n];
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
                scanf("%d",&m1[i][j]);
        }
    }
    int x,y,cont=0,seql,seqc,l2,c2;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
           if(m1[i][j] == m[0][0]){
                seql=0;
                seqc=0;
                cont=0;
                for(l2=i,i=0;i<l ; l2++,i++){
                    for(c2=j,j=0 ;j<l; c2++,j++){

                        if(m[seql][seqc] == m1[l2][c2]){
                            cont+=1;
                            seqc+=1;
                        }
                    }
                    seqc=0;
                    seql+=1;
                }
            }
        if (cont == l*l) {
          break;
        }
      }
        if (cont == l*l) {
            break;
        }
    }
    if(cont ==( l*l)){
        printf("sim\n");
    }
    else{
        printf("nao\n");
    }
    return 0;
}
