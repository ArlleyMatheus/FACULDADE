#include <stdio.h>
int main ()
{
int m [2][2];
int l,c,ab=1,bc=1;
    for (l=0;l<2;l++){
         for (c=0;c<2;c++){
           // printf("digite o numero  : ");
            scanf("%d",&m[l][c]);
         }}
          for (l=0;l<2;l++){
              for (c=0;c<2;c++){

            if (l==c ){
                ab=m[l][c]*ab;
                //printf("sao iquais na posicao%d linha e %d coluna   %d  numero \n ",l+1,c+1,ab);
            }

            if (l!= c){
                    bc =m[l][c]*bc;
//printf("se repetem nas posicaos % linha e coluna %d   numero %d \n",l+1,c+1,bc);
            }}

         }printf(" %d.00\n", ab-bc);

         return 0;
    }





