#include<stdio.h>
int main ()
{
    int n,l,c;
    int m[100][100];
    //printf("digite o tamanho de sua matrix quadrada : ");
    scanf("%d",&n);
        for (l=0;l<n;l++){
            for (c=0;c<n;c++){

                //printf("digite o  %d numeros para a matrix %d ",c+1,n);
                scanf("%d",&m[l][c]);
            }}
              for (l=0;l<n;l++){
                        for (c=0;c<n;c++){
                                  if (l==c){
                                    printf("%d\n",m[l][c]);
                                  }
                        }}
                        return 0;

}






