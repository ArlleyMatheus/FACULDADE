#include<stdio.h>
int main ()
{
    int m[100][100];
    int l,c,n;
   // printf("digite o tamanho da  matriz : ");
    scanf("%d",&n);
            for(l=0;l<n;l++){
                for(c=0;c<n;c++){
                   // printf("digite os numeros para a matriz: ");
                    scanf("%d",&m[l][c]);
                }
                }
                          for(l=0;l<n;l++){
                                for(c=0;c<n;c++){
                                        if (l+c==n-1){
                        printf("%d \n",m[l][c]);
                    }
                }
            }







}
