#include <stdio.h>
#include <stdlib.h>





int main()
{

    int sorteio[6], nv = 0, resultado[6], cQuina, cQuadra, cTotal, i, j, k, c ;

    cQuadra = 0;
    cQuina = cQuadra;
    cTotal = cQuina;


    for(i = 0; i < 6; i++)
    {
        scanf("%d", &sorteio[i]);
    }

    do
    {

        scanf("%d", &nv);

    }while( nv < 1 && nv > 50000);


    for(i = 0; i < nv; i++)
    {
        c = 0;

        for(j = 0; j < 6; j++)
        {
            //scanf("%d %d %d %d %d", &resultado[0], &resultado[1], &resultado[2], &resultado[3], &resultado[4], &resultado[5]);


            scanf("%d", &resultado[j]);



            for(k=0; k<6;k++){


                if(sorteio[k] == resultado[j])
                {
                    c++;

                }

            }




        }

        if( c == 6)
        {
            cTotal++;
        }
        else{
            if(c == 4)
            {
                cQuadra++;
            }
            else
            {
                if(c == 5)
                {

                cQuina++;

                }
            }
        }





    }


    if(cTotal == 0)
    {
        printf("Nao houve acertador para sena\n");
    }
    else
    {
        printf("Houve %d acertador(es) da sena\n", cTotal);
    }


    if(cQuina == 0)
    {
        printf("Nao houve acertador para quina\n");
    }
    else
    {
        printf("Houve %d acertador(es) da quina\n", cQuina);
    }

    if(cQuadra == 0)
    {
        printf("Nao houve acertador para quadra\n");
    }
    else
    {
        printf("Houve %d acertador(es) da quadra\n", cQuadra );
    }

    return 0;

}
