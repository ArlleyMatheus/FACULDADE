#include <stdio.h>
int main ()
{
    int num[10],num2[10],i;



            for(i=0;i<10;i=i+1){
                printf("digite o  %d  numero  " ,i+1);
                scanf("%d",&num[i]);


                       if (num[i]<0){
                            num2[i]=1;
                       }
                                else {
                                    num2[i]=num[i];
                                }
            }

                  for (i=0;i<10;i++){
                    printf("%d  ", num2[i]);

                  }


            }














