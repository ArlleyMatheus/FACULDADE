#include<stdio.h>
int main()
{
   float preco[10],compra[10],l1,l2,l3;

    int i,produto=0,produto2=0,produto3=0;
    for(i=0;i<1;i++){
        printf("digite o valor do preco : ");
        scanf("%f",&preco[i]);
        printf("Digite o valor da compra : ");
        scanf("%f",&compra[i]);
            l1=((10/100)*compra[i])+compra[i];
            l2=((20 /100)*compra[i])+compra[i];
            l3=((20/100)*compra[i])+compra[i];
            if (l1<preco[i],i+1){
                produto=produto+1;
            }
                   if(preco[i]<l1 && preco[i]>l2,i+1){
        produto2=produto2+1;
      }
                  if(l2>preco[i],i+1){
                    produto3=produto3+1;
                  }}
          printf ("os lucros a mais de 10 porcento sao %d \nos a maiores de 10 e  menores que 20 sao %d \n e os maiores de 20 %d \n",produto,produto2,produto3);




}


