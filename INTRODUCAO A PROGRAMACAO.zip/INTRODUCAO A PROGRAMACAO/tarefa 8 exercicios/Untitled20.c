#include <stdio.h>
#include <stdint.h>

                        int *selection_sort(int num[], int tam)
                        {
                            int i, j, min, aux;
                            for (i = 0; i < (tam - 1); i++)
                            {
                                min = i;
                                for (j = (i + 1); j < tam; j++) {
                                    if (num[j] < num[min])
                                        min = j;
                                }
                                if (i != min) {
                                    aux = num[i];
                                    num[i] = num[min];
                                    num[min] = aux;
                                }
                            }

    return *num;

}


int main()
{

    int v1[50000], v2[5000], q1, q2, v3[10000];
    int i, j = 0, k = 0;

    do{

        scanf("%d", &q1);

    } while ((q1 < 0) && (q1 >  sizeof(v1)));

    do{

        scanf("%d", &q2);

    } while ((q2 < 1) && (q2 >  sizeof(v2)));


    for (i = 0; i < q1; i++)
    {
        do{
            scanf("%d", &v1[i]);
        } while ((v1[i] < 0) && (v1[i] > 999999));
    }

    for (i = 0; i < q2; i++)
    {
        do{
            scanf("%d", &v2[i]);
        } while ((v2[i] < 0) && (v2[i] > 999999));
    }

    *v1 = selection_sort(v1, q1);
    *v2 = selection_sort(v2, q2);

    for (i = 0; i < q1 + q2; i++)
    {
        if (i < q1)
        {
            v3[i] = v1[k];
            k++;
        }
        else
        {
            v3[i] = v2[j];
            j++;
        }


    }

    *v3 = selection_sort(v3, q1 + q2);

    for (i = 0; i < q1 + q2; i++)
    {

        printf("%d\n", v3[i]);
    }



    return 0;

}


/*for (i = 1; i < q1 + q2 + 1; i++)
{

if ((i % 2 == 0) && (j <= q2))
{
v3[i-1] = v2[k];
k++;

}

if ((i % 2 != 0)&&( j <= q2))
{
v3[i-1] = v1[j];
j++;

}

if (j >= q2)
{
v3[i - 1] = v1[j];
j++;
}


printf("%d\n", v3[i-1]);

}*/
