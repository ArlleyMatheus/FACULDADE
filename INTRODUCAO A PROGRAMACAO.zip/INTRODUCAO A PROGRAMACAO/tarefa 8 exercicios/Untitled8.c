#include<stdio.h>



main()
{

    int a, b, maior;
      int  vetor[1000], aux;


    scanf("%d", &maior);

    for(a = 0;  a < maior; a++)
    {
        scanf("%d", &vetor[a]);
    }

        for(a=0; a<maior; a++)
    {

        for(b=a; b<maior; b++){

            if(vetor[a] > vetor[b])
            {

                aux = vetor[a];
                vetor[a] = vetor[b];
                vetor[b] = aux;


            }
        }
    }


    for(a = 0; a < maior; a++)
    {
        printf("%d\n", vetor[a]);
    }


}
