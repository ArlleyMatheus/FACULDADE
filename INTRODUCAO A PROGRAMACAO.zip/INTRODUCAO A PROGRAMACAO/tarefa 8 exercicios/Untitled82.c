#include<stdio.h>

main()
{


    int c = 0, a =0, i, j, n, r = 0, num[50000];

    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        scanf("%d", &num[i]);


    }

    for(i = 0; i < n; i++)
    {
        for(j = 1; j < n; j++)
        {
            if(num[i] == num[j])
            {

                a++;
            }
        }

        if(a> c)
        {
            r = num[i];
            c = a;
        }

        a=0;
    }




    printf("%d\n", r);
    printf("%d\n", c);

}
