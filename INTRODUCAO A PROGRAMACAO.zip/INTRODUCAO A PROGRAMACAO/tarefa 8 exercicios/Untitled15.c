#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int *selection_sort(int num[], int tam)
{
    int i, j, min, aux;
    for (i = 0; i < (tam - 1); i++)
    {
        min = i;
        for (j = (i + 1); j < tam; j++) {
            if (num[j] < num[min])
                min = j;
        }
        if (i != min) {
            aux = num[i];
            num[i] = num[min];
            num[min] = aux;
        }
    }

    return *num;

}


int main()
{

    int v[100000], vetor[100000];
    int i, n, j=0;;

    do{
        scanf("%d", &n);
    } while ((n < 0) && (n > 100000));

    for (i = 0; i < n; i++)
    {

        scanf("%d", &vetor[i]);

    }

    *vetor = selection_sort(vetor, n);

    for (i = 0; i < n; i++)
    {



        if (vetor[i]%2 == 0)
        {
            v[j] = vetor[i];
            j++;
        }


    }

    for (i = n-1; i >= 0 ; i--)
    {



        if (vetor[i]%2 != 0)
        {
            v[j] = vetor[i];
            j++;
        }



    }

    for (i = 0; i < n ; i++)
    {

        printf("%d\n", v[i]);


    }





    return 0;
}
