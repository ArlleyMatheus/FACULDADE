#include <stdio.h>
int main ()
{
    int n1[10],n2[10],i;
    for (i=0;i<10;i++){


        printf("digite  %d dez  umeros: 1 para a primeira sequencia:",i+1);
        scanf("%d",&n1[i]);
        printf("digite  %d 10 numeros  para segunda sequencia para sequencia  ; ",i+1);
        scanf("%d",&n2[i]);
} for(i=0;i<10;i++){
 printf("os numeros sao  %d ;%d \n",n1[i],n2[i]);
}

}
