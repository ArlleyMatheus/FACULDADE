#include <stdio.h>

main(){

    int i,n,j,ac11=0,ac22=0,dv11=0,dv22=0;

    scanf("%d",&n);
    int v[11][n];

    for(i=0;i<n;i++)
    {
        for(j=0;j<11;j++)
        {
            scanf("%d",&v[j][i]);
        }
    }

    for(i=0;i<n;i++){

            ac11=0;
            ac22=0;
            dv11=0;
            dv22=0;

            for(j=1;j<=9;j++){
                ac11+=(v[j-1][i]*j);
                ac22+=(v[j-1][i]*(10-j));
            }

            if(ac11%11 == 10)
            {
                dv11 = 0;
            }
            else
            {
                dv11 = ac11%11;
            }

            if(ac22%11 == 10)
            {
                dv22 = 0;
            }
            else
            {
               dv22 = ac22%11;
            }

            if((dv11==v[9][i])&&(dv22==v[10][i]))
            {
                printf("CPF valido\n");
            }
            else
            {
                printf("CPF invalido\n");
            }


    }

}
