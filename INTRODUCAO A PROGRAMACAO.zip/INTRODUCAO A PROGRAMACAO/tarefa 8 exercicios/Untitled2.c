#include <stdio.h>
int main()
{
    int  n[5],n2[5],i;

                for (i=0;i<5;i++){
                    printf("digite o %d  numero de 50: ",i+1);
                    scanf("%d"  ,  &n[i]);
                           n[i];

                }

                       for (i=0;i<5;i++){
                                      if (    n[i]==2*1 ||  n[i]%2!=0) {


                                printf("o numero  na posicao %d e primo \n",i+1);

                            }



                                               else {
                                               printf("o numero na posicao  %d nao e primo  \n",i+1);



                       }

}
}
