#include<stdio.h>
int main ()
{
    int n,j,r;
    printf ("digite um numero ");
    scanf("%d",&n);
    for (j=n;j=1;n-1){


   r=n*j;

    }
    printf("o numero em fatorial = %d ",r);



}








