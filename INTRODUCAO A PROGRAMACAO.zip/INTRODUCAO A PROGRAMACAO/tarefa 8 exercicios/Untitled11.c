#include <stdio.h>

int main()
{

    int i, j, contUnico = 0, contRep = 0, t, vetor[10000];

    scanf("%d", &t);
    for(i = 0; i < t; i++)
    {
        scanf("%d", &vetor[i]);
    }

    for(i = 0; i < t; i++)
    {

        for(j = 0; j < t; j++)
        {
            if(vetor[i] == vetor[j]&&( i != j ))
            {
                contRep++;
                //printf("====%d\n", contRep);
            }
            if(j == t-1)
            {
                if(contRep == 0)
                {
                    contUnico = contUnico + 1;
                    //printf("+++%d\n", contUnico);
                }
            }
        }
        contRep = 0;



    }

    printf("%d\n", contUnico);




}
