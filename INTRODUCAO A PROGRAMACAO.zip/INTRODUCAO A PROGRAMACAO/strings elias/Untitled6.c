#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
    int n,quant=0,i,cont=0;
    char texto[12221];
    //printf("digite  a quantidade de testes que deseja fazer: ");
    scanf("%d",&n);
    getchar();
    while(quant<n){

            //  printf("digite o seu texto para criptografia : ");
            scanf("%[^\n]",texto);
            getchar();


            for(i=0;texto[i]!='\0';i++){
                if(texto[i]>= 'a'&& texto[i]<= 'z' || texto[i]>='A'&& texto[i]<='Z'){
                    texto[i]=texto[i] +3;
                }
                if(texto[i]!=' ');
                cont+=1;
            }
            if(cont%2==0){
                cont;
            }else
            {
                cont=cont+1;
                }
                // printf("cont %d",cont);

            for(texto[i]!='\0';i>=(cont/2);i--){
                if(texto[i]!='\0')
            printf("%c",texto[i]);
            }
            for(i=(cont/2)-1;i>=0;i--){
                texto[i]=texto[i]-1;
                printf("%c",texto[i]);
            }
            printf("\n");

            quant+=1;
            cont=0;
    }
}
