#include<stdio.h>
#include<string.h>
int main (){
    int quant,t=0,i,j,cont=0;
    char primeira [10^4],segunda[10^4];
    //printf("digite a quantidade de testes que deseja fazer : ");
    scanf("%d",&quant);
    while(t<quant){
       // printf("digite a primeira: ");
        scanf("%s",primeira);
        getchar();
       // printf("digite a segunda : ");
        scanf("%s",segunda);
        getchar();
      //  printf("%s\n",primeira);
       // printf("%s\n",segunda);
        i=0,j=0;
        cont=0;
        //printf("i= %d,j= %d cont= %d\n",i,j,cont);
        while(primeira[i]!= '\0' && segunda[j]!= '\0'){
           if(primeira[i] == segunda[j]){
                i++,j++;
            }
            else{

                if(primeira[i] == 'z'){
                    primeira[i]='a';
                    cont+=1;
                }
                if(primeira[i] != segunda[j]){
                   //printf(" %c",primeira[i]);
                    primeira[i]+=1;
                    cont+=1;
                }
            }
       }
       i=0,j=0;
        //for(i=0;primeira[i]!='\0';i++){
          //  printf("%c",primeira[i]);
       //}
      // printf("\n");
      printf("%d\n",cont);
    t++;
    }
}
