#include<stdio.h>
#include<string.h>
#include<stdlib.h>
//void maiuscula(char *frase){
  //  strupr(frase);
//}


int main (){
     int quant,i,t=0,letras=0,vogais=0,consoantes=0;
    char frase[100],caracter;
    //printf("digite  a quantidade de testes : ");
    scanf("%d",&quant);
    getchar();
    while(t<quant){
     //   printf("digite a sua frase: ");
        scanf("%[^\n]s",frase);
        getchar();
  //      maiuscula(frase);


        for(i=0;frase[i]!= '\0' ;i++){
             //  printf("%c",frase[i]);
                  if(frase[i]>= 'a' && frase[i]<='z'||frase[i]>= 'A' && frase[i]<='Z'){
                letras+=1;
            }
            if(frase[i]== 'A' || frase[i]=='E' || frase[i]=='I' || frase[i]=='O' || frase[i]=='U'||
               frase[i]== 'a' || frase[i]=='e' || frase[i]=='i' || frase[i]=='o' || frase[i]=='u'){
                vogais+=1;
            }
            else{
                if(frase[i]>='A' && frase[i]<='Z'||frase[i]>='a' && frase[i]<='z'){
                    consoantes+=1;
                }
            }


      }
     //  printf("frase = %s\n",frase);
    printf("Letras = %d\n",letras);
    printf("Vogais = %d\n",vogais);
    printf("Consoantes = %d\n",consoantes);
    letras=0,consoantes=0,vogais=0;
    t++;
}
}












