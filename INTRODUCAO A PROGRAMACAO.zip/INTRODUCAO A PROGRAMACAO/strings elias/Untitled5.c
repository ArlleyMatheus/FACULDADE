#include<stdio.h>
#include<string.h>
int main (){
    int n,m;
    char soma[999999];
    //printf("digite os valores de N e M : ");
    scanf("%d %d",&n,&m);
    while(n!=0 && m!=0){

       sprintf(soma,"%d",n+m);
      //  printf("%s",soma);

        int i;
        for(i=0;soma[i] != '\0';i++){
            if(soma[i]!='0'){
                printf("%c",soma[i]);
            }
        }
        printf("\n");
   // printf("digite os valores de N e M : ");
    scanf("%d %d",&n,&m);
    }




}
