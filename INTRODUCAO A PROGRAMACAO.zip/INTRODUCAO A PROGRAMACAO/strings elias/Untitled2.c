#include<stdio.h>
#include<string.h>
int main(){
    int n,i=0,a=0;
    char v[1000];
  //  printf("digite o total de repeticoes: ");
    scanf("%d",&n);
    while(a<n){
        scanf("%s",v);
        int soma=0;
        for(i=0;v[i]!= '\0';i++){

          //  printf("%c\n",nome);
            if(v[i]== '1')
                    soma+=2;
                else if(v[i]== '2')
                     soma+=5;
                 else if(v[i]== '3')
                    soma+=5;
                else if(v[i]== '4')
                     soma+=4;
                 else if(v[i]== '5')
                     soma+=5;
                 else if(v[i]== '6')
                     soma+=6;
                else if(v[i]== '7')
                     soma+=3;
                 else if(v[i]== '8')
                     soma+=7;
                else if(v[i]== '9')
                    soma+=6;
                 else if(v[i]== '0')
                    soma+=6;
            }
        printf("%d leds\n",soma);
          a++;
          soma=0;
    }
}
