#include<stdio.h>
#include<string.h>
int main (){
    int  i=0,quant,t=0,j;
    int  n1,n2;
    char num[12221];
   // printf("digite a quantidade de testes que deseja fazer : ");
    scanf("%d",&quant);
    getchar();
    while(t<quant){
      //  printf("digite os numero para a sequencia : ");
        scanf("%d %d",&n1,&n2);
        for( i=n1;i<=n2;i++){
             sprintf(num, "%d", i);
            printf("%s", num);
        }
        for(i=n2;i>=n1;i--){
            sprintf(num,"%d",i);
            for (j = strlen(num)-1; j >= 0; j--) {
                printf("%c",num[j]);
            }
        }
        printf("\n");
        t+=1;
    }
}


