#include<stdio.h>
#include<string.h>
int main(){
    char nome[1000],n1[]={"one"},n2[]={"two"},n3[]={"three"};
    int cont=0;
    int quant,t=0;
   // printf("digite a quantidade de testes que deseja fazer : ");
    scanf("%d",&quant);
    getchar();
    while(t<quant){
      //  printf("digite a sua frase ");
        scanf("%[^\n]",nome);
        getchar();
        int j=0,k=0,l=0,i,caractere,cont1=0,cont2=0;
        for(i=0;nome[i]!='\0';i++){
            if(nome[i]==n1[j] && j<5){
                cont+=1;
                //caractere=1;

            }
            if(nome[i]== n2[k] && k<5){
                cont1+=1;
                caractere=2;

            }
            if(nome[i]==n3[l]&& l<6){
                cont2+=1;
               // caractere=1;

            }
            j++,k++,l++;
        }
        if(cont>=2){
            printf("1\n");
        }
            //printf("cont%d\n",cont);}
        if(cont1>=2){

            printf("2\n");
        }
            //printf("cont1%d\n",cont1);}
        if(cont2>=4){
            printf("3\n");
           // printf("cont2%d\n",cont2);
        }
        j=0,k=0,l=0,cont1=0,cont2=0,cont=0;
    t++;

    }
}
