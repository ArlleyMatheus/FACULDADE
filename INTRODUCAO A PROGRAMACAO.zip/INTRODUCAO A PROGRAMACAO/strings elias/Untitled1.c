#include<stdio.h>
#include<string.h>
int main (){
    char v[50],n[50];
    int i=0,j=0,cont=0,acul=0,quant=0;
    scanf("%d",&quant);

   int  sominha=0;
    while(sominha<quant){
    scanf("%s",&v);
    scanf("%s",&n);
    while(v[cont]!= '\0'){
        cont++;
    }
    while(n[acul]!='\0'){
        acul++;
    }
    int aux=0;
    if(cont>acul){
        aux=cont;
        cont=acul;
        acul=aux;
    }
    int soma=cont+acul;
    int vf[soma];
    int k=0,l=0;
    if(cont == acul){
         //   printf("passou ");
        for(i=0;i<soma;i++){
            if(i%2==0){
                vf[i]=v[k];
                k++;
            }
            else{
                vf[i]=n[l];
                l++;
            }
        }
         for(i=0;i<soma;i++){
           // printf("passou ");
        printf("%c",vf[i]);
    }
      //  printf("passou ");
    }
    else{
           // printf("passou ");
            int dif=acul-cont;
        for(i=0;i<soma-dif;i++){
            if(i%2==0){
                vf[i]=v[k];
                k++;
            }
            else{
                vf[i]=n[l];
                l++;
            }
        }
        for(i=soma-dif;i<soma;i++){
            vf[i]=n[l];
            l++;
        }
         for(i=0;i<soma;i++){
           // printf("passou ");
        printf("%c",vf[i]);
    }
    //printf("passou ");
    }

    printf("\n");

sominha++;
soma=0;
k=0,l=0;
cont=0,acul=0;
}
}











