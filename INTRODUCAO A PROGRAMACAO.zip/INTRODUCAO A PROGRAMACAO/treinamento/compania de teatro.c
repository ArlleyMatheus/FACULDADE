#include<stdio.h>
int main ()
{

    float valor  ,vini,vfin;
    float lucro=0,quantidade=0,conta=0;


    while (vini<)

    printf("digite o valor do ingresso  : ");
    scanf("%f",&valor);
    printf("digite o valor inicial do ingresso : ");
    scanf("%f",&vini);
    printf("digite o valor final do ingresso: ");
    scanf("%f",&vfin);

    conta =200+valor







}
