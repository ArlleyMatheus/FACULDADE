#include<Stdio.h>
int main ()
{
    int n,i,k=0;
    float r= 0;
    printf("digite um numero : ");
    scanf("%d",&n);
    for (i=1;i<=n;i++){
    k=k+1;
    r=(n/i)+r;
printf("%d%d",k,r);
    }
  printf("o numero e %.6f",r);





}
