#include<stdio.h>
int main ()
{
    int n=4;



if (n>0){



   do{
printf("\n\ndigite um numero ;");
scanf("%d",&n);

printf("numero invalido \n") ;
 } while (n<0);}
  if (n%2!=0 || n==2 ){
        printf("o numero  e primo :\\n ");
        }else{
            printf("o numero   nao e primo : \n");
        }
}




