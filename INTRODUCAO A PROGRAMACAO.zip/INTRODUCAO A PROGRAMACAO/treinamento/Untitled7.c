#include <stdio.h>
int main (void){
    //programa para calcular quantidade de cafe para se manter acordado para estudar para a faculdade//
       int cafe_normal  =0;
       int cafe_amargo= 1;
       int cafe_doce= 8;

       printf("digite a quantidades de copos de cafe toma por dia : ");
       scanf("%d",&cafe_normal);
       printf ("quantidade de cafe por  ano ; %d\n\n",cafe_normal*365);
               if (cafe_normal <cafe_doce ){
                cafe_normal=(cafe_normal +cafe_doce)*365;

                printf("quantidade de cafea  aumenta para %d copos por dia\n\n ",cafe_normal/365);
               }else{
                     cafe_normal =(cafe_normal +cafe_amargo)*365;
                     printf("quantidade de cafe diminui  para %dc   copos  por dia \n\n",cafe_amargo /365);
}
}





